# -*- coding: utf-8 -*-
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import sys
import xbmcplugin
import xbmcgui

plugin_handle = int(sys.argv[1])

# Loop TV Live Stream
def Loop():
    url = "plugin://plugin.video.youtube/play/?channel_id=UC1234567890ABCDEF"  # Replace with actual channel ID
    list_item = xbmcgui.ListItem(label="Loop TV Live")
    list_item.setArt({'icon': 'DefaultVideo.png'})
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url=url, listitem=list_item, isFolder=True)

# DaddyLiveV2 Stream
def DaddyLiveV2():
    url = "plugin://plugin.video.youtube/play/?channel_id=UC0987654321FEDCBA"  # Replace with actual channel ID
    list_item = xbmcgui.ListItem(label="DaddyLive V2 Stream")
    list_item.setArt({'icon': 'DefaultVideo.png'})
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url=url, listitem=list_item, isFolder=True)
