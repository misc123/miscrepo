# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from common import *
from food import *

params = get_params()
mode = None

plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.food')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')

#===============================================================================
def Main():

    Add_Dir(
        name="張媽媽廚房", url="plugin://plugin.video.youtube/user/mamacheung/", folder=True,
        icon="https://yt3.ggpht.com/-wuwa4F3RyBE/AAAAAAAAAAI/AAAAAAAAAAA/Yugf9xG3bMc/s100-c-k-no-mo-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="職人吹水", url="plugin://plugin.video.youtube/channel/UCZVmFDfn5WnixrHNf25MeJQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngdVtClUVAO7Y75pirK0vkyHQrpUgi6pas6aolMbj8=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Ricky講煮講食", url="plugin://plugin.video.youtube/channel/UClAIsd91NfxAtdBA0T1h2NQ/", folder=True,
        icon="https://yt3.ggpht.com/EtBef8cHuO8b3eH5qnVzXaGm24ilQB-S9GT0e93oDcHbCNcd-v1YBcs6Wo5wnl34WzikS88riQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="趁熱 Kerry's kitchen", url="plugin://plugin.video.youtube/channel/UCXRcbXqjORdIvl63I7MtOLQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/APkrFKZ0qpCA-Xx-5wEcl-UEFT5WXFQ6v8-f_PKFX8Gc=s800-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="海娟美食", url="plugin://plugin.video.youtube/channel/UCxZj1ezvRm0YrHuEaRrZk-A/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwni6xI3FJxD95hCyObdwbjU7pad_fEMqgahRLJG5=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="天鵝美食", url="plugin://plugin.video.youtube/channel/UCC_C5EHzBqEyW2Oo0QVZpBw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngJBImcD_Iswboj5zeoaOfwp-eQ_OKzvuw3HwvS=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="越煮越好", url="plugin://plugin.video.youtube/channel/UCDfTo6oLw_ZcVfepgTgD_Kg/", folder=True,
        icon="https://yt3.ggpht.com/-y81UYUbzl6k/AAAAAAAAAAI/AAAAAAAAAAA/tTEP3Td-bsE/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg")

    Add_Dir(
        name="疫境廚神", url="plugin://plugin.video.youtube/playlist/PL6xnAvlFTCA2ibLkS3Uih6mm_2R2mwPHZ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyrcChFpzJm3kpa_inzd0JZARIi_MLD-iiOcQ=s88-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="寶寶滋味館", url="plugin://plugin.video.youtube/channel/UCCrXv19nZEi95F0UZ-LyXDg/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mCZyNXpLJJ7qFs4R4-HGbbd52ht039dhVtgvA=s288-mo-c-c0xffffffff-rj-k-no")

    Add_Dir(
        name="Chef Chu's Kitchen", url="plugin://plugin.video.youtube/channel/UCdZ4iamY-QJDEZhBckQpzrQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLReZt_yhB7xT99Cbr_RgY8eRZBzKpyu1yc0jgEq=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="我是马小坏", url="plugin://plugin.video.youtube/channel/UCemTxydROG4XAOS63IY7s8Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSf1m496LAiKmlqC7ISBaMskgtjL5lPsb3eUfZr=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Made With Lau", url="plugin://plugin.video.youtube/channel/UCsIF9vk-I_PV1P-ShDFA84A/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSfTJ-pAcCoVDmHHdnBh1yFwt3XvU5wh9hP6QBp=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Da达哥厨房", url="plugin://plugin.video.youtube/channel/UCqpJKjTsQ7FMMeIDPWHGAnw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLR9Hf1oTWawwDw2tEVs0wdy86Bezr9z7EVdhk-Qyw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="天天相見廚房", url="plugin://plugin.video.youtube/channel/UC1SaDcKftNgCW-I34K462yQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzM5s88nOoca9mzVol6NfZkuO3B4M5-hLzznl0FLw=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="彩虹小厨", url="plugin://plugin.video.youtube/channel/UC_ReTh__D4ZZeaftHZ0GJhA/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwiuRzN72ONc0BvJGDgpudNG_kxEwgDj1HFdGgf=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="大叔食记", url="plugin://plugin.video.youtube/channel/UCaB7FUC5KojXmtjSsdIhJjg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyJQzOjYUljD-r1AfOvS0FGvSOUo_h7tE7jkO1q=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="冯小厨", url="plugin://plugin.video.youtube/channel/UCjVQ9WHx9Lu0kNFaadzDKUg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJw-u19gX9ZDYetoRrf8NGOxekI_VPhwPtK9e-m5=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="田园时光", url="plugin://plugin.video.youtube/channel/UCEkG-qWrskKVdawEFA99koA/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyaEmzF6KHsoHErDYOX1kQAlKk4hObwx_uRmw=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="明聰", url="plugin://plugin.video.youtube/channel/UCZ3X7wpqu7aKdgDCpyQgDyw/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwGfv94DsXVuP2gwG3n3Thf75JRpc65YghDCw=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="點 Cook Guide", url="plugin://plugin.video.youtube/user/dimcookguide/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mDsd7YaWCAZMRgOmdm0EqQ0rH2sYkhR09UFGg=s288-mo-c-c0xffffffff-rj-k-no")

    Add_Dir(
        name="Jing Sang's Kitchen", url="plugin://plugin.video.youtube/channel/UCSfcTjOJPBWZvGZe4JV2KDw/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJy38vPRESpI1fqxEFU9Iy-GQoAogzQ-dmr_xw=s288-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="李晨曦", url="plugin://plugin.video.youtube/channel/UCE2fFvG2dwKWE3VyD4bkOZQ/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mDrGXfXBZg4OYk_4KdUgZx0NuTr4oh7lEwUow=s288-mo-c-c0xffffffff-rj-k-no")

    Add_Dir(
        name="米太廚房手記", url="plugin://plugin.video.youtube/channel/UCcMOC9SMClz663otoRQdObQ/", folder=True,
        icon="https://yt3.ggpht.com/-yXmurm9KMPw/AAAAAAAAAAI/AAAAAAAAAAA/wYFwQJwT4kE/s288-c-k-no-mo-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="日日煮", url="plugin://plugin.video.youtube/channel/UCYDVigTy-NE2KyCqVCiJb_Q/", folder=True,
        icon="https://yt3.ggpht.com/-bccB1jY_CJo/AAAAAAAAAAI/AAAAAAAAAAA/gLoRzxLDN0k/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="Wantanmien", url="plugin://plugin.video.youtube/channel/UCsy5tUhFYchN8BFdXJtECRQ/", folder=True,
        icon="https://yt3.ggpht.com/-mboGmDJr-c4/AAAAAAAAAAI/AAAAAAAAAAA/gtR0e3mpOQM/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="Cooking With May Lynn", url="plugin://plugin.video.youtube/channel/UCAXO1tbQzZ5kOUg3BVl0eYw/", folder=True,
        icon="https://yt3.ggpht.com/-8efBzKvUTuU/AAAAAAAAAAI/AAAAAAAAAAA/2P-lSNWHqOI/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="飲食男女", url="plugin://plugin.video.youtube/search/?q=%e9%a3%b2%e9%a3%9f%e7%94%b7%e5%a5%b3/", folder=True,
        icon="https://yt3.ggpht.com/-UTIHiP9Qp00/AAAAAAAAAAI/AAAAAAAAAAA/a3-HMfQ28wY/s288-c-k-no-mo-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="飲食男女-Backup", url="plugin://plugin.video.youtube/channel/UCzSbfRERtKmU7BuU7ZnGznQ/", folder=True, 
        icon="https://yt3.ggpht.com/uuTxKWWmFBMbGuu3RYtxD48nhjPJWRAhoq6y1gwMe5O3sYeEVx3JdWWI_1KBABSX9beYU8f2Yg=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="入廚秘技", url="plugin://plugin.video.youtube/channel/UCeqUUXaM75wrK5Aalo6UorQ/playlist/PLQcmGU2t4gsp9DBQlqPWjhUy3kr-OwoM-/", folder=True,
        icon="https://yt3.ggpht.com/-qADe85YpptY/AAAAAAAAAAI/AAAAAAAAAAA/czgngNBS3FI/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="港飲港食", url="plugin://plugin.video.youtube/channel/UCeqUUXaM75wrK5Aalo6UorQ/playlist/PLQcmGU2t4gsphUkfAHyO-jPkR5dbR_1Nt/", folder=True,
        icon="https://yt3.ggpht.com/-qADe85YpptY/AAAAAAAAAAI/AAAAAAAAAAA/czgngNBS3FI/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="飲食籽", url="plugin://plugin.video.youtube/playlist/PLBtDO8vnUizoFs2546t1DhockqKoC0i1T/", folder=True,
        icon="https://yt3.ggpht.com/-qADe85YpptY/AAAAAAAAAAI/AAAAAAAAAAA/czgngNBS3FI/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="真英雄素食", url="plugin://plugin.video.youtube/channel/UCryUWjfZLd3Q_aiq677kuGA/", folder=True,
        icon="http://www.realherokitchen.com.hk/online_lesson_youtube/realherokitchen.gif")

    Add_Dir(
        name="Chef Wang 美食作家王刚", url="plugin://plugin.video.youtube/channel/UCg0m_Ah8P_MQbnn77-vYnYw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRQnGQ8ot-NyajS6UnoSjxMlp61fCvtAM_aeRcy=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="留日生活", url="plugin://plugin.video.youtube/channel/UCSno2IYkzCAQTqIPoZG6cDw/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzxcAEfYJcIOWmRBObSZFIrG_Kj9NQHvebVJK1R=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="香港人在多倫多", url="plugin://plugin.video.youtube/channel/UCDYgTnWK6sl-YZEDM4jv7fQ/", folder=True,
        icon="https://yt3.googleusercontent.com/7uTaGKgQ9OJ8kOneDfFYHyF9N7vjZT7hhkJvdsowmi0FLmJIoFjmgfT9A0JqqcCKflobHoMWjQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="李子柒", url="plugin://plugin.video.youtube/channel/UCoC47do520os_4DBMEFGg4A/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyukkMJtjdEYwhB4AyQKVVT9Qyy0tQRrN_TVa4R=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="Helen's Recipes-Vietnamese", url="plugin://plugin.video.youtube/channel/UCMmZEL8jV1B61NKAXcyW87A/", folder=True,
        icon="https://yt3.ggpht.com/-lXWCk1JjtDQ/AAAAAAAAAAI/AAAAAAAAAAA/WimPbqGFPHw/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="CookingWithDog-Japanese w/sub", url="plugin://plugin.video.youtube/channel/UCpprBWvibvmOlI8yJOEAAjA", folder=True,
        icon="https://yt3.ggpht.com/-SixK-U1jMsg/AAAAAAAAAAI/AAAAAAAAAAA/n76jU-5KaTk/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="Maangchi-Korean", url="plugin://plugin.video.youtube/channel/UC8gFadPgK2r1ndqLI04Xvvw/", folder=True, 
        icon="https://yt3.ggpht.com/-d0KStw-ZOOM/AAAAAAAAAAI/AAAAAAAAAAA/0Im0I-Sr9cg/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="Food Wishes", url="plugin://plugin.video.youtube/channel/UCRIZtPl9nb9RiXc9btSTQNw/", folder=True,
        icon="https://i1.ytimg.com/sh/M0InoNcVcRA/showposter.jpg?v=508859c4")

    Add_Dir(
        name="How to Make yummy", url="plugin://plugin.video.youtube/channel/UCECA8Jct_FI6l2tIBLuK7QA/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mBJ-yJRDVb8aeE-ZQPnFoNbylYCYY77ZpNCvQ=s288-mo-c-c0xffffffff-rj-k-no")

    Add_Dir(
        name="Josephine's Recipes", url="plugin://plugin.video.youtube/user/Everydaypossible/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mDf8GRm90gl3axHcLYpGxyIPbcMoJ0NlyWDkg=s288-mo-c-c0xffffffff-rj-k-no")

    Add_Dir(
        name="Nickos Kitchen-Bakery", url="plugin://plugin.video.youtube/channel/UCffs63OaN2nh-6StR6hzfiQ/", folder=True,
        icon="https://yt3.ggpht.com/-R-PA4kxVgkE/AAAAAAAAAAI/AAAAAAAAAAA/JOEZ7x59uWE/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="BBQ Pit Boys", url="plugin://plugin.video.youtube/channel/UCjrL1ugI6xGqQ7VEyV6aRAg/", folder=True,
        icon="https://yt3.ggpht.com/-w5MgnW1qxCw/AAAAAAAAAAI/AAAAAAAAAAA/ywS4ukZBIaM/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="Gabaomom Cuisine", url="plugin://plugin.video.youtube/channel/UCGhLTa2WPbfSyexW2NqZNNQ/", folder=True,
        icon="https://yt3.ggpht.com/o5qwsZc8vq-wQZeLizAh2MU9mTdD4y063H_r_iU3_5S-26q0Uf_hGHQT1rRyIQu9qJMvzLVv9Q=s176-c-k-c0x00ffffff-no-rj")

###---面包生胚---###
    Add_Dir(
        name="[COLOR gold]---面包生胚---[/COLOR]", url="", folder=False)

    video_fav = xbmcgui.ListItem(label="Costco 面包生胚的烘焙温度和烘焙时间 (由Costco 提供)")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=wFvI7mh5vfY", listitem=video_fav, isFolder=False)
    
    video_fav = xbmcgui.ListItem(label="11款COSTCO面包生胚的详细介绍")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=CY401omZakk", listitem=video_fav, isFolder=False)

    Add_Dir(
        name="Costco面包生胚系列-Cynthia‘s Garden", url="plugin://plugin.video.youtube/channel/PLOkrBCzG0EIcmSKVvi98lKSXPjFaOJYPq/", folder=True,
        icon="https://yt3.ggpht.com/ZnW-0W-AUI0_6sD7PjMt1SGdsDTOUFbEIfknh6RJUv-3Y_J5MmY2cmS-MBHJYIxn0ND9090skg=s88-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Costco面包生胚系列-多伦多生活点滴", url="plugin://plugin.video.youtube/channel/PLCLuUnNhBf70_Apc2rY1sMttsuvACGYa-/", folder=True,
        icon="https://yt3.ggpht.com/m5o1qJ0b2JYg2oGxFWc7ECx8R7SsI46Fgf3-Wu2R08k4Oh2_uu9ruBpnXgCdIFJezjhSE90-Sg=s88-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="Costco Brioche dough - Rose Cook 로즈쿡", url="plugin://plugin.video.youtube/channel/PLT9_eLrkThxQOkRox_ArQmFFHi_pmfK3k/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQfvzjnc6ByJnpQ8b2-09XfJA1PgIXSoxhc5BMk=s88-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Judy四月风信的美食日记", url="plugin://plugin.video.youtube/channel/PLhQRAPzsDF8zX1czpJRcUm9jCFVTX3QZ3/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSs4xC1t5_3fbKzIFd1CDuOKyFhBE_YlYiJN5C04Q=s88-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="四月风信的走走停停", url="plugin://plugin.video.youtube/channel/UCQiRFAPnHsejTHGgQm0Dk7A/", folder=True,
        icon="https://yt3.ggpht.com/h3NNeOIFbqRaxUw6RTTU2uKuIKnB0OJxQXrnuE4rOVTzEPiF3HriQjcmRrsN2Vj_0S5acrzQtg=s176-c-k-c0x00ffffff-no-rj")

    video_fav = xbmcgui.ListItem(label="Costco的面包生胚你会玩吗")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=-N_FsGspDf0", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="Costco的面包生胚做中式面食-用面包生胚炸油条炸麻花")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=9DwxBlluwRM", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="Costco的无糖夏巴塔面包生胚")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=nBGyQdXFFKI", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="Costco的零失败 好玩好吃又省钱的面包生胚")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=WgWAF1N6RMM", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="Costco的面包胚做出来的面包")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=B5ZMiJCIa5s", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="Costco的Easy Ham cheese bread")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=NoAT3v7LSg8", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="Costco的Frozen Baked Goods are A Breeze")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=0gqGOR-Pwjg", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="叉燒包-I am Ma Xiaohuai")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=3qReozpFwhw", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="叉烧包的做法-Da达哥厨房")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=udq9v_Osaho", listitem=video_fav, isFolder=False)

###---肠粉---###
    Add_Dir(
        name="[COLOR gold]---肠粉---[/COLOR]", url="", folder=False)
        
    video_fav = xbmcgui.ListItem(label="牛肉肠粉 /米浆的比例")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=lrnJkvUikTI", listitem=video_fav, isFolder=False)
          
    video_fav = xbmcgui.ListItem(label="張媽媽廚房 - 腸粉簡單做法")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=PoQA0lu3aNs", listitem=video_fav, isFolder=False)
         
    video_fav = xbmcgui.ListItem(label="酒樓靚腸粉")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=5mHsmj2t_zM", listitem=video_fav, isFolder=False)
               
    video_fav = xbmcgui.ListItem(label="街檔蒸腸粉豉油")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=vOH6u25G_Rg", listitem=video_fav, isFolder=False)
            
    video_fav = xbmcgui.ListItem(label="腸粉 沙河粉 腸粉醬油")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=xEDyP1e5H1s", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="Steamed Rice Noodle Rolls 3 Ways")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=oghIp0i0Y-Q", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="簡易平底鑊做腸粉")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=TX6PCkSQeyc", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="腸粉 首創最易做法")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=3KVQtUmkBxI", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="蔥花蝦米腸粉配特製甜醬油")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=ARxgDRiaoU4", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="Microwave Mushroom Cheung Fu")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=yQ027MajVSM", listitem=video_fav, isFolder=False)
          
    video_fav = xbmcgui.ListItem(label="HONG KONG STYLE CHEE CHEONG FUN")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=V5J4GBdZUC8", listitem=video_fav, isFolder=False)

###---其他---###
    Add_Dir(
        name="[COLOR gold]---其他---[/COLOR]", url="", folder=False)

    video_fav = xbmcgui.ListItem(label="港式雲吞/雲吞湯做法/清湯 竅門")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=v2SDC1scNlg", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="廣東雲吞")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=tmeBKK-sJTg", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="琥珀合桃")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=txRWcIcThrg", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="氣炸窩琥珀合桃")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=ibiremo1ExM", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="腰果怎樣炸才會香脆")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=abAayOrNwGo", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="氣炸窩腰果")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=E2rUMKzGeKU", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="潮式炸花生")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=0ofnmelLfA4", listitem=video_fav, isFolder=False)
  
    video_fav = xbmcgui.ListItem(label="杏仁酥 Almond Puff Pastry")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=uNtrZ248OPQ", listitem=video_fav, isFolder=False)
  
    video_fav = xbmcgui.ListItem(label="簡單速成蝴蝶酥")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=iYt3d_L8ABQ", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="酥皮點心")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=ziJENa_9-Jo", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="Puff pastry ideas for a party at home!")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=gM_thxhU3Ho", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="酥皮蛋撻-天鵝美食")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=2Gx8fRmeB9k", listitem=video_fav, isFolder=False)
  
    video_fav = xbmcgui.ListItem(label="酥皮蛋撻-wantanmien")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=Ndlv4ZxnRSs", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="蒸蛋糕")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=W7vMIj1PuFA", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="25 ways to mold homemade buns!")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=F9Ahp96YOaA", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="香滑豆腐花-電飯煲做法")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=ACPp3XlROms", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="煲紅豆沙")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=HiOOYP67NNI", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="白果腐竹雞蛋糖水")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=eopsB8F_t-o", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="椰汁年糕 簡單易做版本")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=X2WciiObtDE", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="香酥烤年糕")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=f-4j1llTudg", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="〈職人吹水〉砵仔糕/ 零失敗/簡單做法")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=nBAnOuuRRaM", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="砵仔糕")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=FkMlM9UTHjc", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="麻辣紅油")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=eopsB8F_t-o", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="9种经常做的空气炸锅食谱")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=wePXiPnYNNY", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="簡易食譜］自家製脆皮爆多汁燒肉/燒腩肉")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=8EOr3E-3ctc", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="猪肉直接放酱油中泡2天，味道比腊肉都香")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=26jHlrk55XA", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="生炒糯米飯")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=HK2WFo5OC04", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="9款懷舊小食")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=bC2_8mTNX14", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="牛奶小油条")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=uG9bHIaD4P0", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="鱼汤煮白")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=-Vi0s-u-SM0", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="泡發乾香菇最忌直接加水泡，教你飯店不外傳技巧，2分鐘全泡開")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=LynJ_FmijzE", listitem=video_fav, isFolder=False) 

    video_fav = xbmcgui.ListItem(label="红豆黑豆还是绿豆，煮前多加一步，10分钟全煮烂")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=SVXUpfAtFTY", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="〈職人吹水〉KFC/ 白汁薯仔雞皇飯/ 零失敗")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=MYl39TD7dBE", listitem=video_fav, isFolder=False)              

    video_fav = xbmcgui.ListItem(label="腐乳炒通菜")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=xGm9TxHQd_8", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="荷包蛋做法")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=D2KfDKlDO7U", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="十三間燒臘舖叉燒 & 燒肉試食")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=9YQDeaKUHgE", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="七間店雲吞麵試食兵團")
    video_fav.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=5XWmpRCgVas", listitem=video_fav, isFolder=False)
        

if mode == 0 or mode is None:
    Main()
        
xbmcplugin.endOfDirectory(plugin_handle)
