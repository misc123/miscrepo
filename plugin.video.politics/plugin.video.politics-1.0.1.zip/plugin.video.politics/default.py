# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from common import *
from politics import *

params = get_params()
mode = None

plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.politics')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')

#===============================================================================
def Main():

    Add_Dir(
        name="杨风時評", url="plugin://plugin.video.youtube/channel/UCE05tYKEsEk7Qmhwg5pqcKw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngr3CJnciQrh3Hw2p_QM68a6Qpdli_yzt_MPNCj=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="巴士的報", url="plugin://plugin.video.youtube/channel/UCCBNE0MbFaSooy7ZhJwXSrg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnhub9qdg-gC-HVcqH6zhr9kCNf31qsocRmBoDEYqA=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="磊哥聊政经", url="plugin://plugin.video.youtube/channel/UCD_gy8DWV_DhjJ-bQXF5dGQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzP1GROhwHnIioy4TVg0Xvbbqu7kfLKXQJpGA=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="开心天天", url="plugin://plugin.video.youtube/channel/UCJ0gz1Tuls_ivqxaVt_g2lw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu9lmO4i4uaiXc42X4hWZKM5Ou9R0iVfMWMlZQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="嘉峰时评", url="plugin://plugin.video.youtube/channel/UCXfiyvgIaeR9WdBcXpbeWyA/", folder=True,
        icon="https://yt3.googleusercontent.com/PkmcDcbwqxXupIaQdccET7AmPdGp2hVJDFspxHx_0JHeioQ8pZSRIwHHaJF5wkAQnKrYsxhcz7g=s176-c-k-c0x00ffffff-no-rj")
                
    Add_Dir(
        name="汤山老王", url="plugin://plugin.video.youtube/channel/UCtRJS7qkLIkW7Xdljeaqk8Q/", folder=True,
        icon="https://yt3.googleusercontent.com/n6K17acHSeNK2P-05w3YHA7nTvWuNOBSm8VaAHFZv6uqK9g9WCdbqxSGxhrGoINuV3ULi24G=s176-c-k-c0x00ffffff-no-rj")
                  
    Add_Dir(
        name="直播港澳台", url="plugin://plugin.video.youtube/channel/UC-UFD2pRujktkSyAD999mFg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngpu2fFPt98ST7y5VteaNW7jqfM40n6lyQgnLn6=s176-c-k-c0x00ffffff-no-rj")
                  
    Add_Dir(
        name="德国知事", url="plugin://plugin.video.youtube/channel/UCdXqCN_HtF_RjlsHzDSnJIQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngI4Tqs-riZXHMT_gyiwolO9ogPdbXSsGdqaRCqoQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="起云戰略", url="plugin://plugin.video.youtube/channel/UCKaNq-iZLbgcJGs7T8Z8HCQ/", folder=True,
        icon="https://yt3.googleusercontent.com/9Q_W3jAt7xm_JMGMpyXISgPzxEs6Wbl2WbDs1QNsIXvWsX-EnARu5a8D4icmUbgpi27XF6DW=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="洞见时事", url="plugin://plugin.video.youtube/channel/UCs4Z-fQ0W42K6NVhGiOF77Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQYmik_K_TfT9Cunu9b8ZTDt-277HXimQ7LQzvq=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="暗中观察", url="plugin://plugin.video.youtube/channel/UCcTGHpkUFYspGjTYFIRqp3g/", folder=True,
        icon="https://yt3.googleusercontent.com/QWBpraRAyZgkxqVWHEiRiUDaec4WKbHooFUngI3gUOvjsSNhdPMwYdwLqjK_j5f9V8jytkdr=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="我是毛五", url="plugin://plugin.video.youtube/channel/UCYxHQWKf3YnBu_dKENKzM9Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTGLuvIy3Pjg_kLTo7fM0mpoSvXaCOQuBF_au8=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="江湖百晓生", url="plugin://plugin.video.youtube/channel/UCfqQVT1iMd1_cnahTy1Hieg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu9j_rEvpjo5xZh4u48JgIayLXCXaM7It_tOvtVNJQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="總編輯時間-梁建鋒", url="plugin://plugin.video.youtube/playlist/PLl7zeOiApUFWIYOZw3sJuOPtDdk06O5Ao/", folder=True,
        icon="https://yt3.ggpht.com/a/AGF-l785u6sQF-clevje6FwqIs0k81ZntWgXuSEnYg=s288-c-k-c0xffffffff-no-rj-mo")
        
    Add_Dir(
        name="亚洲特快", url="plugin://plugin.video.youtube/playlist/PLnhpRSU9pPuMCcyIvfjGSfASENr4YXh2_/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRpMradlAYKn492HTcnLjoJG9z3SGndCyQHvxUh6A=s88-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="理科男士K一米", url="plugin://plugin.video.youtube/channel/UCJMEiNh1HvpopPU3n9vJsMQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwni7PXoQGwopk24A5hP9I1Ad7zIVLTZFoOKq0ho9tQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="布解探秘", url="plugin://plugin.video.youtube/channel/UCMr_V1NOgeMForzMtE0-aVg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQtm6U5u1cZt2t0sLUWhsOza5YRI1acfLJ6JxbRqw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="观察者网", url="plugin://plugin.video.youtube/channel/UCJncdiH3BQUBgCroBmhsUhQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwvzvyNXchJysT6OZQ-KEnsxUjZRtjjs0gPZaZixw=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="观视频工作室", url="plugin://plugin.video.youtube/channel/UCYfJG6cGfW84FVLuy7semEg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwKOxGSxCKBl_sKK7LdP7J_7ReLWlkjf_1Pyb4Hgg=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="张维为", url="plugin://plugin.video.youtube/channel/UCtDd5tl977dQrDiNoLhQHkw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnhrumSsFj9FCJH8Pauw52lI5vmURKfLNzWotWOj=s176-c-k-c0x00ffffff-no-rj")        

    Add_Dir(
        name="寒國人", url="plugin://plugin.video.youtube/channel/UCXkOTZJ743JgVhJWmNV8F3Q/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJx5ztsRguSX2MSTYREOEg-YnKrXYt9_r8hI6g=s288-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="Yan Talk 岩论", url="plugin://plugin.video.youtube/channel/UCwNGgFvBpxtU8JagZLzztzQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwniH6JQh4uZHOSRAUUV1mAvfjim1Tpr8buqblYEu=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="新闻日报", url="plugin://plugin.video.youtube/channel/UCBDyUpTT5c3JDLPqY8Nuc5w/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-canXloaR2fz0CbS6pJjbht2ozSI2HiSQ-Yjth=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="小岛大浪吹", url="plugin://plugin.video.youtube/channel/UCYPT3wl0MgbOz63ho166KOw/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AMLnZu-QZvqsA4E1PSVMddExMsBa9VFmEf_vnNz3OS5uTg=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="星球熱點", url="plugin://plugin.video.youtube/channel/UC2r2LPbOUssIa02EbOIm7NA/", folder=True,
        icon="https://yt3.googleusercontent.com/Q0wJomXXFN0U4K9weuNsU7DT7T09heboXcQT8i9NfY0YCq5vd8orgEw9eE4RvT7J81lLak43Gg=s176-c-k-c0x00ffffff-no-rj")
                
    Add_Dir(
        name="7知識局", url="plugin://plugin.video.youtube/channel/UCvFxLkzL0KgDv0B3-leVf5A/", folder=True,
        icon="https://yt3.ggpht.com/Bv6npS0UDxqQCMRJU_nARCFoBkIMYQs7s3YMmMNtmjNRIRLgADsAbHd4H7Qknz-Ox2yGA1rx=s176-c-k-c0x00ffffff-no-rj")              

    Add_Dir(
        name="Hot Topics Time", url="plugin://plugin.video.youtube/channel/UCZPCDOdY4m_m1bqjAl6P9rA/", folder=True,
        icon="https://yt3.googleusercontent.com/mnZx2ysQmJRkcDhUX4RHs8XRVbYm6_T0IGQHiZebPRafxOsDtCR8Rhrpc5L_kIcRJiBB5nKWiw=s176-c-k-c0x00ffffff-no-rj")
                
    Add_Dir(
        name="赖岳谦TV", url="plugin://plugin.video.youtube/channel/UCnrxxRlv2ZSSW4ApuEy8C0w/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-xnof2H-6jr8i1Rl5MojdVJXHzuv1Xfem8OUNwUA=s176-c-k-c0x00ffffff-no-rj")        

    Add_Dir(
        name="Chong San 沖先生", url="plugin://plugin.video.youtube/channel/UCsGqE-IVUCwyyi_WRsvVLJg/", folder=True,
        icon="https://yt3.ggpht.com/XbJK4MQLInnB3FCn0FI1KB3NgJdczSH43QbcX77XAsklvseyviRr93ZzFhmgWxI1swAvRBpybw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="中天新聞", url="plugin://plugin.video.youtube/channel/UCpu3bemTQwAU8PqM4kJdoEQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu_GcqEtH92jxUu-uPnd6Z2KRScKh_Qi1T9M0mgluQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="军武侦察兵", url="plugin://plugin.video.youtube/channel/UCU2t_Mq9F97eWHJfgBom_wg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu9XL6NnJ3nG9HNAunK_nnu5qIYkjqwZKmePn85Qrg=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="龍騰大中國", url="plugin://plugin.video.youtube/channel/UCtmltVWKWMD7POU6NUW5PVA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu_2MHSz9haficKalbmRUXfbVt9rNAbLVGl0oe-ohQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="時政焦點", url="plugin://plugin.video.youtube/channel/UCHGg-bh_-x6YqVakEkql49A/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSPUvq0fkbU5RcOHc84lMOHo-gC0LJV6Js-wDO8sA=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="利刃观察", url="plugin://plugin.video.youtube/channel/UCSyzXqH32Pv05iqpBsLYgcA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu_Bdil1D90BZ64lIoGmIrOp0xM4bhhjBv9tsBsh=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="屈機TV", url="plugin://plugin.video.youtube/channel/UCN0eCImZY6_OiJbo8cy5bLw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSgEAGosPXetUZ8L_3eSFfYeTRWV159HSdrqWb7=s176-c-k-c0x00ffffff-no-rj")
                 
    Add_Dir(
        name="K2秀", url="plugin://plugin.video.youtube/channel/UCLqn_8sNfaye3wwNC1PfPIQ/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AGIKgqPdKlAR7CK-HehxGLPXfIeZS0jwgy9K5COLqWtb=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="Ming仔", url="plugin://plugin.video.youtube/channel/UCDoEdJo-PI-EKGNKomwLroQ/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AL5GRJWXSWaein_lDcN-f3ARHQkXEwXDWuH3xDHIwmWv0g=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="東網點評",
        url="plugin://plugin.video.youtube/channel/UC4NjmIegGw-HyQCmxwAEZBQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwniNC13K7MkFYxvSslIs1iPz9oBLje83s1LWGd4Tlw=s88-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="极客队长官方频道GeekLead", url="plugin://plugin.video.youtube/channel/UCaW3MoZA0LMrZt9WFXtyvNQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSKnj5tiEhI8-SEm1RTuVaI95AwowDUGixNCQWs=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="冼師傅講場", url="plugin://plugin.video.youtube/channel/UCFRBCHEqZNJ2Rb1IjrCC8Zw/", folder=True,
        icon="https://yt3.ggpht.com/a/AGF-l7_Qg35rIi0wFPrOGCObxPdm5k2y8qSAX6a4Og=s288-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="傅正", url="plugin://plugin.video.youtube/playlist/PLr0JU8OOrK4iENkcC5UWrHM88Hbr5X7QU/", folder=True,
        icon="https://i1.hdslb.com/bfs/face/b5a5301e9d55f4a7fa24cbc84690eeb9b86c5ad6.jpg@240w_240h_1c_1s.webp")

    Add_Dir(
        name="楊世光在金錢爆", url="plugin://plugin.video.youtube/channel/UCrm095p7ZHRS1njmQ1wkgCg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLS9plBmDiY6CoMUPNK5JWYGgfYGojwL7JS8X51jiw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="李天豪", url="plugin://plugin.video.youtube/channel/UCOrcp--cu4Egwdc07X44btA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSFhfNqDOvZE3pJ8sP_OPH-iSHt5PeDuW0w8qH1KA=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="王志郁Plus", url="plugin://plugin.video.youtube/channel/UCy-pqt2qjYVDZqwBiTS9yDA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRf9DO0RtOk7gZNyUrpBYau3TSixouNJHGZgD2N2g=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="我是柳傑克", url="plugin://plugin.video.youtube/channel/UC000Jn3HGeQSwBuX_cLDK8Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSyvQcw2l-ZhydsWKuTwQ3d4zoNA0joKQArA0aiXw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="东京自干五-长脸博士传媒", url="plugin://plugin.video.youtube/channel/UCzjhdu0yMChb8vRz8Ky3LCg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSdTjWgSLMuKdSnt-FwqUYsfMMSNSXBsyzLApXXxw=s88-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="WION", url="plugin://plugin.video.youtube/channel/UC_gUM8rL-Lrg6O3adPW9K1g/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTjMUv7cELVis5Au9R2HRytJnMtLShdD_k4IaeFQA=s176-c-k-c0x00ffffff-no-rj")
                
    Add_Dir(
        name="Asian Boss", url="plugin://plugin.video.youtube/channel/UC2-_WWPT_124iN6jiym4fOw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSHNaY_YBOYiS4J4pHleM9h2LhgpOFTOGqU9AThpw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="东方卫视环球交叉点", url="plugin://plugin.video.youtube/channel/UCG4kGP4ETdKzseQshMCCBKg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTCWOqJffksmrwkiRThZk3OCBg_-qfXT5t4k5bcTw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="中国梦时代", url="plugin://plugin.video.youtube/channel/UCltlJhJae9lCBnrtpQs53lw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRkfL2vxMBkXVYyx1Mo6zJvHtBhpKgicgn2EkPDbA=s176-c-k-c0x00ffffff-no-rj")
                
    Add_Dir(
        name="中国新观察", url="plugin://plugin.video.youtube/channel/UCjVRKYmoezJ5A9iCvFomV1g/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTGQPdjf03uF2LgIuLX50YPCPe4beTWhMHGbMokhw=s176-c-k-c0x00ffffff-no-rj")
                 
    Add_Dir(
        name="环球新视野", url="plugin://plugin.video.youtube/channel/UC6aT6m2WuXUfzoahv1hDIaw/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJz0ihZHbWZdPNZBcM7bc9HUIO6K_XrvyQcLGA=s288-c-k-c0xffffffff-no-rj-mo")
                 
    Add_Dir(
        name="龙之声", url="plugin://plugin.video.youtube/channel/UCjpF47XO6JfF9QVmXoRociQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLS2svK55tNextjFxjqpcTSXg7IlpZ3vzOFOu9aq=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="卢克文", url="plugin://plugin.video.youtube/channel/UClTVEzPs4aNRXl3xDfMKqaA/", folder=True,
        icon="https://i2.hdslb.com/bfs/face/c0a1b1f382c68da453f5a273ce069ee46e685364.jpg@225w_225h_1c.webp")

    Add_Dir(
        name="环球观察", url="plugin://plugin.video.youtube/channel/UC6iTaivn7fHD8rmPQKcUdQg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnh6ERfeIPeRq8k26myDBqW-n-LGduOBIVELrQgB=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="胡锡进Global Times", url="plugin://plugin.video.youtube/channel/UCVD-MGxD71IQUk9_hHq8MdA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnh07drypjn7U6BZ-3_vW4FTbAZXrU8Q195P0sVO=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="诚阅 ChengYue", url="plugin://plugin.video.youtube/channel/UCd6umYVQpBZ9CIyCwe8Kg7w/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJxgeqxuisbDAlXj9v7wI6b_1z-pYW8wHRYjAylu=s176-c-k-c0x00ffffff-no-rj")
            
    Add_Dir(
        name="全球大視野", url="plugin://plugin.video.youtube/channel/UCiwt1aanVMoPYUt_CQYCPQg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnj2DjFWmKz2gqvNpgy5ElO_Zd25NGbbapBy-0mEFw=s176-c-k-c0x00ffffff-no-rj-mo")
                
    Add_Dir(
        name="军政速递", url="plugin://plugin.video.youtube/channel/UCdyh01hxhKg6uTurnLdickQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngx1r4JjslB2Q8aVBbn1pVCFyK6hu1vb7zlIDX1=s176-c-k-c0x00ffffff-no-rj")
                
    Add_Dir(
        name="国际时评", url="plugin://plugin.video.youtube/channel/UC8HvBg9Rw-cUz0tqKdkKkNg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnguzTBHPbmCvhN3yhwdkFZ-Z_Fy5Hsb-GsB2vnG=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="快看资讯", url="plugin://plugin.video.youtube/channel/UCgkHTZsCdH8P9z7lazTXN3g/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzB-L487V6_1Q5-qx5hw2xrsMsZVqF0BLE9fg=s288-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="點新聞", url="plugin://plugin.video.youtube/channel/UCcrnNcl12onXCeS_3Bi0a2Q/", folder=True,
        icon="https://yt3.ggpht.com/a/AGF-l79aat4yF9qy5E0uqRiFt4d4t40Q4VZknha4IA=s288-c-k-c0xffffffff-no-rj-mo")
        
    Add_Dir(
        name="新潮民", url="plugin://plugin.video.youtube/channel/UCzV8ytvWEGtMWk0wt9zA1Ng/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnjxUU5eZLp-MAoU7hJDFSlJMmRT2O5KrSc1XO38cw=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="KOLHK 時事梓引", url="plugin://plugin.video.youtube/channel/UCG6WtLOTXySl1terUhQYWCA/", folder=True,
        icon="https://yt3.ggpht.com/NDTvGFU50VALAyt8F6jbhS73gSkpgIGRcWMa6umMEgdCSVj7Dwug7552xLCTi6giI6L0ZMpEi5w=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="陳穎欣Joephy Chan", url="plugin://plugin.video.youtube/channel/UCvlBe-TQfjLFINSSYQt9Tjg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyelSSdVCQhptmAxwrUMmVMVSO13zueU_mOnQ=s144-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="大樹與木頭 ‧Y2K Channel", url="plugin://plugin.video.youtube/channel/UCFfLWSnUCblI4Lpsph7H1lA/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJymkSjncCTZJiz3q8Vpss4LVzKnfX5KctTyPmteRA=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="娜娜琳", url="plugin://plugin.video.youtube/channel/UCn0Lyn2rx4ZJcHgD-jgNhiw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnjwbRazIvLSThIvvt1Z4auaoaNzlsAafuzot2HN=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="空姐牛肉飯Annie", url="plugin://plugin.video.youtube/channel/UCpytXTSrsqbCjmqb6MfMrmw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnjE3Ycu_cj3RRlhLzJc0BkKkthOvAYUeV9HIkhXBg=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="Chong San 沖先生", url="plugin://plugin.video.youtube/channel/UCsGqE-IVUCwyyi_WRsvVLJg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngM7DJO1yuLEI0KvbMpR6CBSBIys6sI9aD4V-AN=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="有聲專欄", url="plugin://plugin.video.youtube/playlist/PL50ryNxlMBN5kwOJ_DvTeNXhBrQRbm9N6/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyGzUS1KUF4yZ1VnwWZI8UxEU-4KJhHLr1Lf_dwfA=s100-c-k-c0xffffffff-no-rj-mo")
        
    Add_Dir(
        name="Vovan222prank", url="plugin://plugin.video.youtube/channel/UC7aFhtshxOnaqioFAJ0ZSvA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLS71RehjZ8viATHcp5QHyTV8DAN33dDTJlvE9ySkQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="火鍋大王Nathan Rich", url="plugin://plugin.video.youtube/channel/UCaSlyjhR4WC7QhYuaivxb6g/", folder=True,
        icon="https://yt3.ggpht.com/a/AGF-l78ngY4lsF1M-z5fRTQxaHGjsHEOJ5Ly2gpjyQ=s288-mo-c-c0xffffffff-rj-k-no")

    Add_Dir(
        name="和之梦", url="plugin://plugin.video.youtube/channel/UCwHUYtwH5E41O6MiYoC19ng/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSgBajZNqy03PTZe0WjiBSVH_zln38X3yAkTHyMHg=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="印度三哥MANU马怒", url="plugin://plugin.video.youtube/channel/UC9rRTrTFBo-ntv7Cx10D2QA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwng3LEsnMLW2NJo-fntq-NNLYihved5LdGd9rvs3=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="台積與中芯最終命運, 巴菲特購台積股權之謎", url="plugin://plugin.video.youtube/kodion/search/query/?q=EKujoLAEO5A", folder=False)
                  
    Add_Dir(
        name="【科普/体验】数字人民币是什么？使用体验如何？数字人民币简单科普与试点地区体验", url="plugin://plugin.video.youtube/kodion/search/query/?q=h6KeIG1umtI", folder=False)
                  
    Add_Dir(
        name="国产GPU如何突围？AI芯片与CPU/GPU有何不同？", url="plugin://plugin.video.youtube/kodion/search/query/?q=7EXDp6c9n-Q", folder=False)
  
    Add_Dir(
        name="2008次貸危機 & 2023 svb银行危机", url="plugin://plugin.video.youtube/kodion/search/query/?q=Ak8x7pKZ7pw", folder=False)

    Add_Dir(
        name="美联储加息減息“剪羊毛", url="plugin://plugin.video.youtube/kodion/search/query/?q=T6cVPxET77I", folder=False)
                  
    Add_Dir(
        name="美国如何利用加息降息周期收割全世界", url="plugin://plugin.video.youtube/kodion/search/query/?q=dhEsJt7qo8o", folder=False)
                  
    Add_Dir(
        name="美國長臂管轄", url="plugin://plugin.video.youtube/kodion/search/query/?q=bc26Tt5B9Ik", folder=False)
    
    Add_Dir(
        name="南海那场世纪对峙", url="plugin://plugin.video.youtube/kodion/search/query/?q=WXJ6LC4mvHM", folder=False)
                
    Add_Dir(
        name="一堂課帶你看懂烏克蘭危機", url="plugin://plugin.video.youtube/kodion/search/query/?q=m6sRBEpHBpw", folder=False)

    Add_Dir(
        name="NGO颠覆史（上）", url="plugin://plugin.video.youtube/kodion/search/query/?q=Tb_g8UgkyRI", folder=False)

    Add_Dir(
        name="美國佔領一個國家的12個步驟", url="plugin://plugin.video.youtube/kodion/search/query/?q=qyqKDomSeUk", folder=False)

    Add_Dir(
        name="美國掠奪一個地方的四部曲", url="plugin://plugin.video.youtube/kodion/search/query/?q=zffGd8RQhTA", folder=False)

    Add_Dir(
        name="美國謀害中國陷入圈套的十個步驟1", url="plugin://plugin.video.youtube/kodion/search/query/?q=ddlyL6gqffM", folder=False)

    Add_Dir(
        name="美國謀害中國陷入圈套的十個步驟2", url="plugin://plugin.video.youtube/kodion/search/query/?q=6X4DHDuILIo", folder=False)

    Add_Dir(
        name="美國謀害中國陷入圈套的十個步驟3", url="plugin://plugin.video.youtube/kodion/search/query/?q=lxdQPMcxz78", folder=False)

    Add_Dir(
        name="孟晚舟案", url="plugin://plugin.video.youtube/kodion/search/query/?q=NOkZeEC5li8", folder=False)

    Add_Dir(
        name="x孟晚舟案全部真相", url="plugin://plugin.video.youtube/kodion/search/query/?q=6_dhlL5z9kw", folder=False)
                
    Add_Dir(
        name="x从英雄到恶魔，环保少女被欧洲清算", url="plugin://plugin.video.youtube/kodion/search/query/?q=ylJyflgz3YI", folder=False)
               
    Add_Dir(
        name="x美国如何印钞收割全球", url="plugin://plugin.video.youtube/kodion/search/query/?q=Fni8y0TJWOg", folder=False)
             
    Add_Dir(
        name="x美国如何控制全球的糧食", url="plugin://plugin.video.youtube/kodion/search/query/?q=xf5GnGpDVFc", folder=False)
       
    Add_Dir(
        name="x中国对抗霸权的终极武器", url="plugin://plugin.video.youtube/kodion/search/query/?q=tlaQ2KONzx0", folder=False)

    Add_Dir(
        name="x中國如何反制美國“剪羊毛", url="plugin://plugin.video.youtube/kodion/search/query/?q=ZNUhwXykgZs", folder=False)
        
    Add_Dir(
        name="x美國房地產次貸危機", url="plugin://plugin.video.youtube/kodion/search/query/?q=Hjtnxq7qZ7M", folder=False)
   
    Add_Dir(
        name="x日本半導體之衰落", url="plugin://plugin.video.youtube/kodion/search/query/?q=fCgyc-XwzI4", folder=False)
   
    Add_Dir(
        name="x貨幣互換,本幣結算", url="plugin://plugin.video.youtube/kodion/search/query/?q=mQAaXQJNVJQ", folder=False)
 

if mode == 0 or mode is None:
    Main()
        
xbmcplugin.endOfDirectory(plugin_handle)
