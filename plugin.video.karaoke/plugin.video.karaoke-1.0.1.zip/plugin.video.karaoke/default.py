# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from common import *
from karaoke import *

params = get_params()
mode = None

plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.karaoke')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')

#===============================================================================
def Main():

    addDirMain('Karaoke',BASE,10,'special://home/addons/plugin.video.karaoke/icon/karaoke.png','fanart.jpg')
    addDirMain('咪咕愛唱',BASE,20,'special://home/addons/plugin.video.karaoke/icon/aichang.png','fanart.jpg')
#===============================================================================
#@route(mode='咪咕愛唱')    
def 咪咕愛唱():

    package_name = "com.iflytek.aichang.tv"
    activity_name = ""  # You may leave this empty or provide the specific activity name if required
    xbmc.executebuiltin('StartAndroidActivity({}, {})'.format(package_name, activity_name))
#===============================================================================   
#@route(mode='Karaoke')    
def Karaoke():


    Add_Dir(
        name="Sing King (Artist Playlists)", url="plugin://plugin.video.youtube/channel/UCwTRjvjVge51X-ILJ4i22ew/playlists/", folder=True,
        icon="https://yt3.ggpht.com/OEM_YWX9rSnUxjoxCkNNMPQZxM37JRBZe8wVK2otPQdnly_gpDdqV45CsmIz3R2BEnKtlNbacg=s800-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Atomic Karaoke (Male/Female/All)", url="plugin://plugin.video.youtube/channel/UCutZyApGOjqhOS-pp7yAj4Q/playlists/", folder=True,
        icon="https://yt3.ggpht.com/ytc/APkrFKaeMXJiU1zc9UHl-k41eXu1Dj9vl08w1TsS05C5=s800-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Stingray Karaoke (1-4Hr non-stop)", url="plugin://plugin.video.youtube/channel/UCYi9TC1HC_U2kaRAK6I4FSQ/", folder=True,
        icon="https://yt3.ggpht.com/L9sZ8pk7Trqrgr5YP2COcoGFTmilu1qfxuNDBSU24pgq5j5Atv_DpJ97IAtPnv_Mmv3hVVkiog=s176-c-k-c0x00ffffff-no-rj-mo")

    Add_Dir(
        name="KaraFun", url="plugin://plugin.video.youtube/channel/UCbqcG1rdt9LMwOJN4PyGTKg/playlists/", folder=True,
        icon="https://yt3.ggpht.com/-fYBYIzoKwv0/AAAAAAAAAAI/AAAAAAAAAAA/gOIMUmKxXT8/s100-c-k-no-mo-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="The Karaoke Channel (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLB8w1Qc67s0yuxWtaMQfzkHx4ECIWlv-Z/", folder=True,
        icon="")

    Add_Dir(
        name="GOLDEN BUZZER (Male/Female)", url="plugin://plugin.video.youtube/channel/UCaX4eZVkG0zb1tjGRKjivuw/playlists/", folder=True,
        icon="https://yt3.googleusercontent.com/g5Q7U56X0OztYPIjnW5D_zK7nc9mGg6X2RJ6MVuUwqPAOVLSU3Q34XprTBg4E_vjVyfA0ZAYqw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Pinoy Videoke Tambayan (Male/Female/Oldies/Slow Rock)", url="plugin://plugin.video.youtube/channel/UCj8MrQPTFj08bCg_G0WLFVg/playlists/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/APkrFKYlepFGm_w6lEqHZGM02OComUosRwxNlY2J-hjQ5A=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Harco Karaoke (Male/Female/Rock Bands)", url="plugin://plugin.video.youtube/channel/UCosZn5efkFY8qJqOBBIf-2A/playlists/", folder=True,
        icon="https://yt3.googleusercontent.com/1NYb8RiTCkE_WtE8kFJz-FdGHl5mR2mKAbHZtrbPHywChL-aYkANxPXoymA4eU-t6tjL5mLC=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="English Karaoke (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLBXZUdrg4E58lU1ZetBmHLMyFR170CfLU/", folder=True,
        icon="")

    Add_Dir(
        name="Original Karaoke", url="plugin://plugin.video.youtube/channel/UCnM6QQeanPgBRyEMeFmrNnA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLR7ru1krEdq7LxKb8GchedkLa3df5K68Ylaes-m=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Musisi Karaoke", url="plugin://plugin.video.youtube/channel/UCJw1qyMF4m3ZIBWdhogkcsw/playlists/", folder=True,
        icon="https://yt3.ggpht.com/hMJzKhyjOLnZhg5BqMiRvxjTKvJTxqU8vCbG1AVvs-EFtsPkoHHm-W95NF0TkmMJLOhPq9XCTLQ=s176-c-k-c0x00ffffff-no-rj-mo") 

    Add_Dir(
        name="sing2piano | Piano Karaoke (Male/Female/All)", url="plugin://plugin.video.youtube/channel/UCIk6z4gxI5ADYK7HmNiJvNg/playlists/", folder=True,
        icon="https://yt3.ggpht.com/a3vqe_NJa2kFxltxDBIIZ2i8ISft5ot-VX7F5wVMtytORhzEkC6Bd4tlwhqO5Jp-_eC5l6tK=s800-c-k-c0x00ffffff-no-nd-rj")


###---Chinese Karaoke---###
    Add_Dir(
        name="[COLOR gold]---Chinese Karaoke---[/COLOR]", url="", folder=False)       
        
    Add_Dir(
        name="Using Karaoke (國/粵語/合唱/英語KARAOKE)", url="plugin://plugin.video.youtube/channel/UCIm-6DtIcos0bvLWvQbxfmQ/playlists/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/APkrFKYlUS_hBWujhGfhwA6T_9U_JPG5iHakcCJgdk1n=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="KaraOK4Ever (大量歌手分類)", url="plugin://plugin.video.youtube/channel/UCRVRXXUrPu8WH2pq1wdL5mg/playlists/", folder=True,
        icon="https://yt3.googleusercontent.com/rqbzIN_3iJQQFp4uaxyDYWJoC0JrbS1pa6foihUXpjdb3mFqDTAE9CxZflRotgtL8_EpIcrXUkw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="jckaraok (大量歌手分類)", url="plugin://plugin.video.youtube/channel/UC0uQLKZ4JE51pYGQn_3WbXQ/playlists/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/APkrFKaYVSTlIOT_XYmW2aSUNFhyP_ILGEN12xNLjlWvLQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="lifeisgood181(許冠傑/鄧麗君)", url="plugin://plugin.video.youtube/channel/UCyVkF7-i7UN46xx0srDHcHg/playlists/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/APkrFKY-tXYXRM0em5-EVXFkhFe7lrclJ17MpnOTJQkz=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="鄧麗君伴唱歌曲 (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLPnSzsy6dnJPqfb8fv-abd0bppR_4R2s_/", folder=True,
        icon="")

    Add_Dir(
        name="廣東 KTV", url="plugin://plugin.video.youtube/channel/UCRM8u1OeKNcHmKojukYHGdA/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/APkrFKZMAiMb9fm-UVP5W9pRQzbRoLukVdf5WH646sYJlA=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="粤语KARAOKE歌曲 (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLPnSzsy6dnJOGeVqoX1z3ZM409ElJf0q6/", folder=True,
        icon="")

    Add_Dir(
        name="粤语 Karaoke 伴唱 (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLPnSzsy6dnJMWcRqiKWKa_qLZ-8NKeBTh/", folder=True,
        icon="")

    Add_Dir(
        name="Karaoke去人声歌曲 (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLPnSzsy6dnJOFAXbTjiftbGD_Ub-bPlPd/", folder=True,
        icon="")

    Add_Dir(
        name="Karaoke 中文歌精選 (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLBXZUdrg4E58DHwaglXCpcFhftct61s4a/", folder=True,
        icon="")

    Add_Dir(
        name="Karaoke 中文老歌精選 (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLBXZUdrg4E59gTN45Q09V1RhqX5KBZhvs/", folder=True,
        icon="")

    Add_Dir(
        name="中文Karaoke伴唱 (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLPnSzsy6dnJOP3rIPEjas3oAx9pStWYnQ/", folder=True,
        icon="")

    Add_Dir(
        name="Karaoke伴唱 (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLPnSzsy6dnJMmo8PdOHbYzCjvA8Sg6Z0p/", folder=True,
        icon="")

    Add_Dir(
        name="国语Karaoke (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLPnSzsy6dnJNdajVSLD86olHQbHO1bxpj/", folder=True,
        icon="")

    Add_Dir(
        name="Karaoke 男女合唱歌 (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLBXZUdrg4E5_IXmQ0X2nwwtxs89tqHjie/", folder=True,
        icon="")

    Add_Dir(
        name="araoke 男女合伴奏歌曲 (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLPnSzsy6dnJPAvBz39t_iFIXtmw91GBkA/", folder=True,
        icon="")

    Add_Dir(
        name="Karaoke男伴女或女伴男合唱 (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PPLPnSzsy6dnJPG5R2pif4uL2v9EccDDYSd/", folder=True,
        icon="")

    Add_Dir(
        name="Karaoke (歌手分類)", url="plugin://plugin.video.youtube/channel/UCXS_c6FPzJVKXjPAnoY9xoQ/playlists/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/APkrFKZJ5wHm1xqwTfuD-66X_u3bcrfRkXpHM8q03anBSw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Karaoke伴奏歌存庫 (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLKtsg20rNeyB32KB2sTiw6b_TTlRy-oK7/", folder=True,
        icon="")

    Add_Dir(
        name="【經典流行歌曲】舊歌新唱 (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLKtsg20rNeyC2fOau4TUBFXOcuYx_4zB2/", folder=True,
        icon="")

    Add_Dir(
        name="Love Song 聽歌 (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLKtsg20rNeyDnG6LeCPuW9WmWDPNAhBU-/", folder=True,
        icon="")

    Add_Dir(
        name="第一国語Karaoke伴唱 (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLPnSzsy6dnJP-hPMbVr88tphftohd2yds/", folder=True,
        icon="")

    Add_Dir(
        name="第二国語Karaoke伴唱 (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLPnSzsy6dnJMVaSvbTsByEeVkKxOs757m/", folder=True,
        icon="")

    Add_Dir(
        name="第三国语伴奏Karaoke (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLPnSzsy6dnJPVMn-ocp-6wocBblVCNxlV/", folder=True,
        icon="")

    Add_Dir(
        name="Joe Chen", url="plugin://plugin.video.youtube/channel/UC85seHs93FlKEkQBRoqpbcw/", folder=True,
        icon="")

    Add_Dir(
        name="傷心的音符musica china canal", url="plugin://plugin.video.youtube/channel/UCK0Hf_8e4tPmcd_11dXe4RQ/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/APkrFKYn6sfU4g48vOGLYhySTq85VkuDTxJ1OOy4YsJl=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="No Vocal Channel (Mandarin Male/Female)", url="plugin://plugin.video.youtube/channel/UCsPV2YljNEYb8vWxM3F52DQ/playlists/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/APkrFKZ41sL2LBYx3YdFS0ZWIAbgPp-vNvEZbL68sEer=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="K歌王迷你KTV (KTV)", url="plugin://plugin.video.youtube/channel/UC6yEBiJuBPQLEoGRtEwoPxg/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/APkrFKaMkQVVUFaqkWVVLbuV8kFuW018dm_N3jIY8LyL=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="龍聖卡拉OK Chinese Karaoke w PinYin", url="plugin://plugin.video.youtube/channel/UCZLdo3vi6B5h-yp2p3V2msQ/", folder=True,
        icon="https://yt3.googleusercontent.com/6Kp69EQzRbYzH6G-GO89H1KZ4Czx36hOimCe27_HhovitA2jvkejSdk7JLlKdDNTnmKOdjjY=s176-c-k-c0x00ffffff-no-rj")


###---Kids Karaoke---###
    Add_Dir(
        name="[COLOR gold]---Kids Karaoke---[/COLOR]", url="", folder=False)
        
    Add_Dir(
        name="DISNEY SING-ALONGS", url="plugin://plugin.video.youtube/playlist/PLPCp3Td3qajCIo0UEi-V_Hs-nRqnEgWgG/", folder=True,
        icon="https://yt3.ggpht.com/TSF_A_ziF7NK-s2jgfnq1SEbmTBbatIinmtXuSRxx_3nlqZRsz99OADuns3AzlKkioBaWsI19A=s88-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="The Ultimate Disney Songs (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLY8ZoU3QxiG3I4XtrmWwCSDh7Pt6y09zL", folder=True,
        icon="https://i5.walmartimages.com/asr/b189fd24-505c-43b5-b6e5-c41bb7dddae3_1.be1f8a6e57319371bdd8096ff96c59b0.jpeg?odnHeight=450&odnWidth=450&odnBg=FFFFFF")

    Add_Dir(
        name="STAR Kids Music", url="plugin://plugin.video.youtube/channel/UCKRAGrBPMw4Mo1KEbqhycPQ/playlists/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLR13EJ0-xXiyEn6aMhLYshcO0dMT8H5lWhuDuSv=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Nursery Rhymes Karaoke (Collection from other Channels)", url="plugin://plugin.video.youtube/playlist/PLWFhFAVbZO5mp8Djy-olPSUz8Atg4y3Ov", folder=True, 
        icon="http://a3.mzstatic.com/us/r30/Purple/v4/11/87/00/1187004b-64a9-eda9-de74-df7ddff21016/screen480x480.jpeg")        

    Add_Dir(
        name="ChuChu TV Nursery Rhymes & Kids Songs", url="plugin://plugin.video.youtube/channel/UCBnZ16ahKA2DZ_T5W0FPUXg/playlists/", folder=True, 
        icon="https://yt3.googleusercontent.com/ytc/APkrFKZPV4J839Rbl6HPlbmBM5RToskBd-rL5rv0CgXrkQ=s176-c-k-c0x00ffffff-no-rj")        

#xbmcplugin.endOfDirectory(plugin_handle)
    
#==========================================================================================================
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def regex_get_all(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
    return r

#====================================================

params=get_params()
url=None
name=None
mode = None
iconimage=None
description=None

#===================== Python 2 ======================

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#===================== Python 3 ======================

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.parse.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
#==========================================================================================================

if mode==10:
    Karaoke()
 
elif mode==20:
    咪咕愛唱()
    
elif mode==None:
    Main()
        
xbmcplugin.endOfDirectory(plugin_handle)
