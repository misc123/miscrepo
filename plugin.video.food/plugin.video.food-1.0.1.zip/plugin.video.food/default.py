# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from common import *
from food import *

params = get_params()
mode = None

plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.food')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')

#===============================================================================
def Main():

    Add_Dir(
        name="張媽媽廚房", url="plugin://plugin.video.youtube/user/mamacheung/", folder=True,
        icon="https://yt3.ggpht.com/-wuwa4F3RyBE/AAAAAAAAAAI/AAAAAAAAAAA/Yugf9xG3bMc/s100-c-k-no-mo-rj-c0xffffff/photo.jpg")



if mode == 0 or mode is None:
    Main()
        
xbmcplugin.endOfDirectory(plugin_handle)
