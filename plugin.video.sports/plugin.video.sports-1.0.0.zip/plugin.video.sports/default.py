# -*- coding: utf-8 -*-
import sys, os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

# Plugin setup
plugin_handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.sports')
home = addon.getAddonInfo('path')

def addDir(name, url, icon, fanart, isFolder):
    list_item = xbmcgui.ListItem(label=name)
    list_item.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url=url, listitem=list_item, isFolder=isFolder)

def Main():
    # The Loop (external plugin)
    addDir(
        name='The Loop',
        url='plugin://plugin.video.the-loop/',
        icon='special://home/addons/plugin.video.the-loop/icon.png',
        fanart='fanart.jpg',
        isFolder=True
    )

    # DaddyLive V2 (external plugin)
    addDir(
        name='DaddyLive V2',
        url='plugin://plugin.video.dlv2/',
        icon='https://cmanbuildsxyz.com/cman/repo/plugin.video.dlv2/icon.png',
        fanart='fanart.jpg',
        isFolder=True
    )

    # Add more plugins here if needed

Main()
xbmcplugin.endOfDirectory(plugin_handle)
