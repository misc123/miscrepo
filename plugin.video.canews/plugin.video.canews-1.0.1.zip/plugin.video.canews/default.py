# -*- coding: utf-8 -*-
import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from urllib.parse import parse_qs, unquote, quote
import html
import xml.etree.ElementTree as ET
import os

plugin_handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.canews')

def get_params():
    param_string = sys.argv[2][1:] if len(sys.argv) > 2 else ''
    params = dict(parse_qs(param_string))
    return params

params = get_params()
mode = int(params.get('mode', [0])[0])

def Main():
    xml_path = os.path.join(addon.getAddonInfo('path'), 'resources', 'favourites.xml')
    tree = ET.parse(xml_path)
    root = tree.getroot()

    favourites = []

    for fav in root.findall('favourite'):
        name = fav.get('name')
        thumb = fav.get('thumb', '')
        raw_action = fav.text or ''

        play_match = re.search(r'PlayMedia\("(.+?)"\)', raw_action)
        activate_match = re.search(r'ActivateWindow\(10025,\s*\"(.+?)\",\s*return\)', raw_action)
        android_match = re.search(r'StartAndroidActivity\("(.+?)"\)', raw_action)

        if play_match:
            favourites.append({'name': name, 'thumb': thumb, 'action': 'playmedia', 'url': play_match.group(1)})
        elif activate_match:
            favourites.append({'name': name, 'thumb': thumb, 'action': 'activatewindow', 'url': activate_match.group(1)})
        elif android_match:
            favourites.append({'name': name, 'thumb': thumb, 'action': 'startandroidactivity', 'url': android_match.group(1)})
        else:
            xbmc.log(f"Unrecognized favourite: {raw_action}", xbmc.LOGWARNING)

    for fav in favourites:
        name = fav['name']
        thumb = fav['thumb']
        action = fav['action']
        url = fav['url']

        plugin_url = f"plugin://{addon.getAddonInfo('id')}/?mode=1&action={action}&target={quote(url)}"
        list_item = xbmcgui.ListItem(label=name)
        if thumb:
            list_item.setArt({'thumb': thumb, 'icon': thumb, 'fanart': thumb})

        xbmcplugin.addDirectoryItem(handle=plugin_handle, url=plugin_url, listitem=list_item, isFolder=False)

def handle_action():
    action = params.get('action', [None])[0]
    target = params.get('target', [None])[0]
    if not action or not target:
        xbmc.log("Missing action or target", xbmc.LOGERROR)
        return
    target = unquote(target)
    if action == 'playmedia':
        xbmc.executebuiltin(f'PlayMedia("{target}")')
    elif action == 'activatewindow':
        xbmc.executebuiltin(f'ActivateWindow(10025, "{target}", return)')
    elif action == 'startandroidactivity':
        xbmc.executebuiltin(f'StartAndroidActivity("{target}")')
    else:
        xbmc.log(f"Unknown action: {action}", xbmc.LOGERROR)

if mode == 0:
    Main()
elif mode == 1:
    handle_action()

xbmcplugin.endOfDirectory(plugin_handle)
