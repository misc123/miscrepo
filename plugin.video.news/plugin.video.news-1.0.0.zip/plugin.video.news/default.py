# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from common import *
from news import *

params = get_params()
mode = None

plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.news')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')

#===============================================================================
def Main():

    Add_Dir(
        name="無綫7:30一小時新聞", url="plugin://plugin.video.youtube/playlist/PLKoXXVQa3yxCbgfZiuq61w9UhEI085PHu/", folder=True)
    Add_Dir(
        name="明報5:30加拿大新聞", url="plugin://plugin.video.youtube/channel/UCuaiQk1XUTc3q4HaL36E_Dg/", folder=True)
    Add_Dir(
        name="TVBusa - 東張西望", url="plugin://plugin.video.youtube/kodion/search/query/?q=tvbusa%e6%9d%b1%e5%bc%b5%e8%a5%bf%e6%9c%9b", folder=True)
    Add_Dir(
        name="香港01", url="plugin://plugin.video.youtube/channel/UCTxyBu9VWUq5LXezXwy_SGg/", folder=True)
    Add_Dir(
        name="香港V", url="plugin://plugin.video.youtube/channel/UCJngFlPRJELUXCwl08PZvqg/", folder=True)
    Add_Dir(
        name="i-Cable News 有線新聞", url="plugin://plugin.video.youtube/playlist/PLIpRvnEkgEeVUPzeLS6JraRwmD3YcWkMz/", folder=True)
    Add_Dir(
        name="ViuTV", url="plugin://plugin.video.youtube/channel/UCHOmxBZKt6uCFqoCvRHnSgQ/playlists/", folder=True)
    Add_Dir(
        name="AMM 亞洲心動娛樂", url="plugin://plugin.video.youtube/channel/UCTsSh20JYvvFlHQ9NYzj1mg/playlists/", folder=True)
    Add_Dir(
        name="MPWeekly明周", url="plugin://plugin.video.youtube/user/Mingpaoweekly/", folder=True)
    Add_Dir(
        name="HK娛樂驛站", url="plugin://plugin.video.youtube/channel/UCGT-CnExA28xbZNX4AYp1tg/", folder=True)
    Add_Dir(
        name="明星周刊", url="plugin://plugin.video.youtube/channel/UCvM04RAO0VeVLoLqRF_MEcQ/", folder=True)
    Add_Dir(
        name="TVB (official)", url="plugin://plugin.video.youtube/channel/UCD2SNRlEjxJODlwaKx-BoRw/playlists/", folder=True)
    Add_Dir(
        name="TVB Anywhere Life", url="plugin://plugin.video.youtube/kodion/search/query/?q=TVB%20Anywhere%20Life", folder=True)
    Add_Dir(
        name="TVB Variety Show 綜藝娛樂", url="plugin://plugin.video.youtube/channel/UCflTI_nq4yyQK3B9UITRJFw/", folder=True)
    Add_Dir(
        name="TVB Food &amp; Travel 飲食旅遊", url="plugin://plugin.video.youtube/channel/UC0FCCZhGfa-BnohSaQjwXGA/playlists/", folder=True)
    Add_Dir(
        name="TVB Mystery Channel 神秘頻道", url="plugin://plugin.video.youtube/kodion/search/query/?q=TVB%20Mystery%20Channel%20%e7%a5%9e%e7%a7%98%e9%a0%bb%e9%81%93&amp;search_type=playlist", folder=True)
    Add_Dir(
        name="TVB Drama – Action WuXia 動作武俠", url="plugin://plugin.video.youtube/channel/UCcadjKOwi1MLRlXb78aGx-Q/playlists/", folder=True)
    Add_Dir(
        name="TVB Best Drama 熱播劇場", url="plugin://plugin.video.youtube/channel/UC-vdzV9IVeIsp0YSCm16CkQ/playlists/", folder=True)
    Add_Dir(
        name="TVB Drama – Comedy 喜劇台", url="plugin://plugin.video.youtube/channel/UC3zIehcse5c7xRdE-baFVfw/playlists/", folder=True)
    Add_Dir(
        name="TVB Crime &amp; Mystery Channel 神秘頻道", url="plugin://plugin.video.youtube/channel/UCYEcRcwNhGS3fAYVrOneFew/playlists/", folder=True)
    Add_Dir(
        name="亞視精選 Drama Asia", url="plugin://plugin.video.youtube/channel/UCCyJ08FwnuhEvsT7QSrWBhA/playlists/", folder=True)
    Add_Dir(
        name="ViuTV World", url="plugin://plugin.video.youtube/kodion/search/query/?q=ViuTV%20World&amp;search_type=playlist", folder=True)
    Add_Dir(
        name="有線電視節目列表", url="plugin://plugin.video.youtube/channel/UC_q7e5XYJB0JDGagcF0KW0w/playlists/", folder=True)
    Add_Dir(
        name="Now 財經新聞", url="plugin://plugin.video.youtube/channel/UCChMBgirwM2nnT3Bbe8METQ/playlists/", folder=True)
    Add_Dir(
        name="八八通", url="plugin://plugin.video.youtube/channel/UCeFbWIhDj_tjTOTe1P3cVHA/", folder=True)
    Add_Dir(
        name="東Touch", url="plugin://plugin.video.youtube/user/EastTOUCHhk/", folder=True)
    Add_Dir(
        name="東周網", url="plugin://plugin.video.youtube/channel/UCsTeCS6s9YoNn2kbQVAgDsQ/", folder=True)
    Add_Dir(
        name="頭條日報", url="plugin://plugin.video.youtube/user/hkheadlinenews/", folder=True)
    Add_Dir(
        name="《危險人物》翁靜晶", url="plugin://plugin.video.youtube/channel/UCqz7Q8gOavVi_ZiGHePvLug/playlist/PLPbX1ivjKJuJ1SO0lDA0o8E80JEywnYl0/", folder=True)
    Add_Dir(
        name="解密工作室", url="plugin://plugin.video.youtube/channel/UCtokllq2j9bzPD6XdcQP9mQ/", folder=True)
    Add_Dir(
        name="Mr. Atom 原子檔案", url="plugin://plugin.video.youtube/kodion/search/query/?q=Mr.%20Atom%20%e5%8e%9f%e5%ad%90%e6%aa%94%e6%a1%88", folder=True)
    Add_Dir(
        name="Just For Fun", url="plugin://plugin.video.youtube/channel/UCfmhgy-jmq_P2m-rSXsEq3g/", folder=True)
    Add_Dir(
        name="娛樂香港新聞透視", url="plugin://plugin.video.youtube/channel/UCLtcC8s-2JJ_5iUxcAO462Q/", folder=True)
    Add_Dir(
        name="明報新聞(多倫多,加國及其他)", url="plugin://plugin.video.youtube/channel/UCuaiQk1XUTc3q4HaL36E_Dg/playlists/", folder=True)
    Add_Dir(
        name="多倫多 WOWtv", url="plugin://plugin.video.youtube/channel/UC5kySUzP0p4Q4Y1rnQLX_bw/", folder=True)
    Add_Dir(
        name="恩雨之聲", url="plugin://plugin.video.youtube/channel/UCgwOhn9ghL2jY5qJEzpzSzw/", folder=True)
    Add_Dir(
        name="Lorey Chan 好書推介", url="plugin://plugin.video.youtube/playlist/PLFkHgNWcmIh6kwEP_rPXfcFKAh__L4cmt/", folder=True)
    Add_Dir(
        name="Mr &amp; Mrs Gao", url="plugin://plugin.video.youtube/channel/UCMUnInmOkrWN4gof9KlhNmQ/", folder=True)
    Add_Dir(
        name="科学声音", url="plugin://plugin.video.youtube/channel/UCUBhobCkTLhgfUNRAgHSYmw/", folder=True)
    Add_Dir(
        name="這麼遠 那麼近-方東昇", url="plugin://plugin.video.youtube/channel/UCaA4Wqk9sf2prQbjoVBtnPw/playlist/PLCGAsPLmtY28brHkRXonte3LDEY7pr_X5/", folder=True)
    Add_Dir(
        name="長命百二歲-方東昇", url="plugin://plugin.video.youtube/channel/UCvdc-bj7Onv5XhEC5z8_JUg/playlist/PLhbhEbEB8P3r7CBSv0zuLCHq7a-AGWU9U/", folder=True)
    Add_Dir(
        name="世界零距離-方東昇", url="plugin://plugin.video.youtube/channel/UCvdc-bj7Onv5XhEC5z8_JUg/playlist/PLhbhEbEB8P3qHxdq__peUJM2aM1zc7YVs/", folder=True)
    Add_Dir(
        name="挑战不可能 Impossible Challenge", url="plugin://plugin.video.youtube/channel/UC3HLhJGcc_0Vse2UncGnxcQ/", folder=True)
    Add_Dir(
        name="御赐小仵作", url="plugin://plugin.video.youtube/channel/UC3PKcYXUAhao3p4kuNS4_9w/playlist/PL9yRf-Ghij3YIJj8j2Y8rEVMWBqGuLD9A/", folder=True)
    Add_Dir(
        name="琅琊榜Nirvana In Fire", url="plugin://plugin.video.youtube/channel/UC0jYsshDZfOBZC9nIJn94Cg/playlist/PLtt_YYUGi1gXRt2XVJZrHDBkZECcfmuAJ/", folder=True)
    Add_Dir(
        name="志雲飯局", url="plugin://plugin.video.youtube/kodion/search/query/?q=%e5%bf%97%e9%9b%b2%e9%a3%af%e5%b1%80", folder=True)
    Add_Dir(
        name="多倫多華基主日粵語崇拜講道", url="plugin://plugin.video.youtube/kodion/search/query/?q=%e5%a4%9a%e5%80%ab%e5%a4%9a%e8%8f%af%e4%ba%ba%e5%9f%ba%e7%9d%a3%e6%95%99%e6%9c%83%e5%8d%88%e5%a0%82%e5%b4%87%e6%8b%9c", folder=True)


if mode == 0 or mode is None:
    Main()
        
xbmcplugin.endOfDirectory(plugin_handle)
