# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from common import *
from livetv import *

params = get_params()
mode = None

plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.livetv')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')

#===============================================================================
def Main():
    import urllib.parse
    base_url = "https://hklive.tv"
    path = "/list.m3u"
    url = base_url + path + "?channel=電視直播"
    list_item = xbmcgui.ListItem(label="香港電視直播")
    list_item.setInfo("video", {"title": "電視直播"})
    list_item.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)

if mode == 0 or mode is None:
    Main()
        
xbmcplugin.endOfDirectory(plugin_handle)
