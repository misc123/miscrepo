# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from common import *
from politics import *

params = get_params()
mode = None

plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.politics')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')

#===============================================================================
def Main():

    Add_Dir(
        name="杨风時評", url="plugin://plugin.video.youtube/channel/UCqM0FLGjP9amUeXLWJlzUdA/", folder=True,
        icon="https://yt3.ggpht.com/1hnWBT09pExajwC01yzNvAvQPJvZzns_IWnITOcc5ZdkNNbhS6m0ZgNQOZAQqHKAYdw2cZmxg4A=s800-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="磊哥聊政经", url="plugin://plugin.video.youtube/channel/UCD_gy8DWV_DhjJ-bQXF5dGQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzP1GROhwHnIioy4TVg0Xvbbqu7kfLKXQJpGA=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="巴士的報", url="plugin://plugin.video.youtube/channel/UCCBNE0MbFaSooy7ZhJwXSrg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnhub9qdg-gC-HVcqH6zhr9kCNf31qsocRmBoDEYqA=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="大刘说说", url="plugin://plugin.video.youtube/channel/UC9Q8KmHEHhDl_2LSiQNGLaQ/", folder=True,
        icon="https://yt3.googleusercontent.com/RF9ryQsiNaFqx0UapP8oYBmu7Sa6nX_QQmiSyaLInHyBZAedh1uAQnKBUyK3X8Qt4SkUK_vQ=s176-c-k-c0x00ffffff-no-rj")
                
    Add_Dir(
        name="汤山老王", url="plugin://plugin.video.youtube/channel/UCtRJS7qkLIkW7Xdljeaqk8Q/", folder=True,
        icon="https://yt3.googleusercontent.com/n6K17acHSeNK2P-05w3YHA7nTvWuNOBSm8VaAHFZv6uqK9g9WCdbqxSGxhrGoINuV3ULi24G=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="白呀白Talk", url="plugin://plugin.video.youtube/channel/UCjEqklvNFQYeqUPEmLY30jg/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AIdro_miHTRSXQfpnhgPbQwEnRRPBBRbarKFZM62Dn6sdjQSnvI=s160-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="老石谈芯 Shilicon Talk", url="plugin://plugin.video.youtube/channel/UC5mVFJf71Ax6TJZcbmTnilw/", folder=True,
        icon="https://yt3.googleusercontent.com/o1XiRuloimBL5O7tQXtpuEqYAJr1_ybWcUSFZ5SpHuHLG_H7WoZDz6QKZj7B0kc0hXTRVpSHNQ=s160-c-k-c0x00ffffff-no-rj")
       
    Add_Dir(
        name="Showpics", url="plugin://plugin.video.youtube/channel/UCxAEbNbFWLMoLiZpYttZ25g/", folder=True,
        icon="https://yt3.googleusercontent.com/niLtyAY7DsB9YJmG80o36oKoJBcX639y9KhXIQFD52QbCQMQHt_6R9XXbLAIWlBFaarE045o8Q=s160-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="大黃和她的視界", url="plugin://plugin.video.youtube/channel/UC8t_ckkm3gbEeJR6Ed0iwzg/", folder=True,
        icon="https://yt3.googleusercontent.com/o97q5f0Btjuooyz2ZmetS9bOZG1f4Q0ZVwRXbHUFEE9--aR2W9iSdnvJxW5tPkX1pJzed2Bsag=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="張經義", url="plugin://plugin.video.youtube/channel/UCGKJCCcbagf9J7Cj4xl2_0Q/", folder=True,
        icon="https://yt3.googleusercontent.com/oMP_F1c7r5lA1v2cMlR6m4s5O5mSdIscQVlTQ8Xy8M56jp5ABgGoOJwJ-r_QQQkQ3Dfgx5q3UmM=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="布解探秘", url="plugin://plugin.video.youtube/channel/UCMr_V1NOgeMForzMtE0-aVg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQtm6U5u1cZt2t0sLUWhsOza5YRI1acfLJ6JxbRqw=s176-c-k-c0x00ffffff-no-rj")
 
    Add_Dir(
        name="金灿荣教授", url="plugin://plugin.video.youtube/channel/UCT9l2xL8HhfCV5F9GtOxPpg/", folder=True,
        icon="https://yt3.ggpht.com/lMyoF4GT4l-q9Sptwxkel5bq5Va4KWJdw8tT3jmluoOSXgF493SWcCClenvDeK4LD4Sn-5TY2A=s800-c-k-c0x00ffffff-no-rj")        
 
    Add_Dir(
        name="张维为", url="plugin://plugin.video.youtube/channel/UCtDd5tl977dQrDiNoLhQHkw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnhrumSsFj9FCJH8Pauw52lI5vmURKfLNzWotWOj=s176-c-k-c0x00ffffff-no-rj")        

    Add_Dir(
        name="總編輯時間-梁建鋒", url="plugin://plugin.video.youtube/playlist/PLl7zeOiApUFWIYOZw3sJuOPtDdk06O5Ao/", folder=True,
        icon="https://yt3.ggpht.com/a/AGF-l785u6sQF-clevje6FwqIs0k81ZntWgXuSEnYg=s288-c-k-c0xffffffff-no-rj-mo")
 
    Add_Dir(
        name="星球熱點", url="plugin://plugin.video.youtube/channel/UC2r2LPbOUssIa02EbOIm7NA/", folder=True,
        icon="https://yt3.googleusercontent.com/Q0wJomXXFN0U4K9weuNsU7DT7T09heboXcQT8i9NfY0YCq5vd8orgEw9eE4RvT7J81lLak43Gg=s160-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="坤姐闯江湖", url="plugin://plugin.video.youtube/channel/UC5E7XKf6rtUktGaV7G6mxfA/", folder=True,
        icon="https://yt3.googleusercontent.com/D85UExTZdmVTqICjkYuyX2ZVd3lGUL8unDtf8ORC27rqmTKe9xo-7UVwQKOTwOQa6J2nFxtEnw=s160-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="理科男士K一米", url="plugin://plugin.video.youtube/channel/UCJMEiNh1HvpopPU3n9vJsMQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwni7PXoQGwopk24A5hP9I1Ad7zIVLTZFoOKq0ho9tQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="劉定堅狠辣批評", url="plugin://plugin.video.youtube/channel/UCMXWPVv1VVBD2jMdEB_nfdQ/", folder=True,
        icon="https://yt3.googleusercontent.com/Hk7Vm2bVYIHkCgfMEcSKSUN8J8AigeYPvB2Lpmny8hEPVQUgdrOEpb4g2X1TOmIJMPSu8669Fg=s160-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="「呂志華」聲音雜誌", url="plugin://plugin.video.youtube/channel/UCep6BJWdCRB08KMJnAKxzLw/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AIdro_k6ri3QyY26MPb0wBB3nzvSBZrjlnhzEgpEw6XZKR_QLw=s160-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="坏土豆联盟", url="plugin://plugin.video.youtube/channel/UCYV8jDDgUMQcbP7be_g9Ynw/", folder=True,
        icon="https://yt3.googleusercontent.com/VA5-5n_ngqTg7PlbalTJz1p6i4M7unQHqZZa9H0K_LTfa7mGyLXEwA-T3jHxJE6gj3IvSUI0zA=s160-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="我是毛五", url="plugin://plugin.video.youtube/channel/UCYxHQWKf3YnBu_dKENKzM9Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTGLuvIy3Pjg_kLTo7fM0mpoSvXaCOQuBF_au8=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="说三道四", url="plugin://plugin.video.youtube/channel/UCpVIhYElyw0O1oGep7eYiOQ/", folder=True,
        icon="https://yt3.ggpht.com/mUkqScWuKUuJWREQl1_kCqKm-3MboFXdH0aD8ymHZy3q-3PFPLPB5222rblukiDrVpAaQjpCUQ=s800-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="开心天天", url="plugin://plugin.video.youtube/channel/UCJ0gz1Tuls_ivqxaVt_g2lw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu9lmO4i4uaiXc42X4hWZKM5Ou9R0iVfMWMlZQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="德国知事", url="plugin://plugin.video.youtube/channel/UCdXqCN_HtF_RjlsHzDSnJIQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngI4Tqs-riZXHMT_gyiwolO9ogPdbXSsGdqaRCqoQ=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="亚洲特快", url="plugin://plugin.video.youtube/playlist/PLnhpRSU9pPuMCcyIvfjGSfASENr4YXh2_/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRpMradlAYKn492HTcnLjoJG9z3SGndCyQHvxUh6A=s88-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="逸语道破", url="plugin://plugin.video.youtube/playlist/PLnhpRSU9pPuPtgF90t2drWKTdCe9OvB5H/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRpMradlAYKn492HTcnLjoJG9z3SGndCyQHvxUh6A=s88-c-k-c0x00ffffff-no-rj")
       
    Add_Dir(
        name="东方卫视环球交叉点", url="plugin://plugin.video.youtube/channel/UCG4kGP4ETdKzseQshMCCBKg/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AIdro_l42QSKZsKzce9OB02N69V3QxA1q338p1CR4GRXQmOJh00=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="曲博科技教室 Dr. J Class", url="plugin://plugin.video.youtube/channel/UCq8Xi8muhehxRMIK76I1jog/", folder=True,
        icon="https://yt3.googleusercontent.com/R4YIdsQiht0lumslrY2ouRIQkdxVK3zmwl3xdG45pifesE11l2oocYW5M2xGsW4F3axSxiL6=s160-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="极客队长官方频道GeekLead", url="plugin://plugin.video.youtube/channel/UCaW3MoZA0LMrZt9WFXtyvNQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSKnj5tiEhI8-SEm1RTuVaI95AwowDUGixNCQWs=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="和之梦", url="plugin://plugin.video.youtube/channel/UCwHUYtwH5E41O6MiYoC19ng/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSgBajZNqy03PTZe0WjiBSVH_zln38X3yAkTHyMHg=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="寒國人", url="plugin://plugin.video.youtube/channel/UCXkOTZJ743JgVhJWmNV8F3Q/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJx5ztsRguSX2MSTYREOEg-YnKrXYt9_r8hI6g=s288-c-k-c0xffffffff-no-rj-mo")
        
    Add_Dir(
        name="傑克街訪", url="plugin://plugin.video.youtube/playlist/PLPTjSeTGvjg-NuE_lB61RDd9ZL4S-XgN7/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AIdro_mobc2Jt_DGl79yDIDwvYsHIZPdhS7TKfZDItj1HFpzYFI=s160-c-k-c0x00ffffff-no-rj")
 
    Add_Dir(
        name="大衛Sir", url="plugin://plugin.video.youtube/channel/UCX016cNODDxgtrmJRat3eTQ/", folder=True,
        icon="https://yt3.googleusercontent.com/ZrQ5ot_For3GTFn2SXqr5TZfejLAUmS9Gz1oH1DXEsT7DJ9zfT9kCrv-2KlsZCvjtDp_beDv=s160-c-k-c0x00ffffff-no-rj")        
        
    Add_Dir(
        name="中文油管排行榜", url="plugin://plugin.video.youtube/playlist/UCpVe3swmfUtmo0hLtJYOjag/", folder=True,
        icon="https://yt3.googleusercontent.com/41NkfoVt3SXfnNWauHSa_MNbjEePbyIztuzYnGzkooW-RyVBy2QybzIBhLaCkTm1YMgyfWse=s160-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Chris Kohler-Products from Top to Bottom", url="plugin://plugin.video.youtube/channel/UC9xafGPnAr0hxZ_bYMp1JsQ/", folder=True,
        icon="https://yt3.googleusercontent.com/FQamBCSvfBg96gG2MyULq8f40Ou420Y21AW5ybm2etvzURPmMYeUX5tazzXgnzY3S35Qc49ExA=s160-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Rise of Asia", url="plugin://plugin.video.youtube/channel/UCij3VomCDlQr4bVNnG9shzg/", folder=True,
        icon="https://yt3.googleusercontent.com/-jAeeK4yjF7iJFDM5jckA1O875RqVeiN2-gDiAzh94x-V74ohBtOcmEHXhT2DOqLjVE0as5c=s160-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="环球叶问", url="plugin://plugin.video.youtube/channel/UCG4kGP4ETdKzseQshMCCBKg/playlist/PLAyEv1wrVt_Pj1b0ceOnmlPInQxvNNzQW/", folder=True,
        icon="https://i.ytimg.com/vi/myuDxg9D15s/hqdefault.jpg")

    Add_Dir(
        name="包明说", url="plugin://plugin.video.youtube/channel/UCJ9UIHPdUdpnVxO3vVuR4Sg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AOPolaTLZAZVjZ4u2AsUjXF2_u-Its3u2wYha_5nyus=s800-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="香江望神州-", url="plugin://plugin.video.youtube/channel/UCSwoCb9L7sJxL7dmDnicYEQ/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AIdro_m3zdPtiLcC2tsTimFRcIpEbAdwI1CeFqn8WHsw1rewfrY=s160-c-k-c0x00ffffff-no-rj")
 
    Add_Dir(
        name="灼見名家-灼見政治", url="plugin://plugin.video.youtube/kodion/search/query/?q=《灼見政治》", folder=True)

    Add_Dir(
        name="看看新闻Knews", url="plugin://plugin.video.youtube/channel/UC3R12t6KHGtTTC6y0eQeR4w/", folder=True,
        icon="https://yt3.ggpht.com/9vPT0shM5_DGWauX1u5do99CYDbhoIPLK4tKu9zCbZmZCxdCkRtxBmPZQFRFqa-d7O2Oqq4Q=s800-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="观察者网", url="plugin://plugin.video.youtube/channel/UCJncdiH3BQUBgCroBmhsUhQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwvzvyNXchJysT6OZQ-KEnsxUjZRtjjs0gPZaZixw=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="观视频工作室", url="plugin://plugin.video.youtube/channel/UCYfJG6cGfW84FVLuy7semEg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwKOxGSxCKBl_sKK7LdP7J_7ReLWlkjf_1Pyb4Hgg=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="黎建南", url="plugin://plugin.video.youtube/channel/UCBQNoL1nikGqmBIq9LOp3Xw/", folder=True,
        icon="https://yt3.googleusercontent.com/-uL9BJFOuTQlfdEegTlOW3TZ1zeE5K8c-upLJoZzEvgUdCO8RwRvEgc9A1hEK5i74l04poYk=s160-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="残月铁榔头", url="plugin://plugin.video.youtube/channel/UCC22zTYPmf9p20E_abhp-uw/", folder=True,
        icon="https://yt3.googleusercontent.com/M29v863NOzVMrDVDoY85SCaCGapkM5jVUNaHd0ln9ax0WgMouBEUhLwOorZrcdukDk4EaXhMpw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="起云戰略", url="plugin://plugin.video.youtube/channel/UCKaNq-iZLbgcJGs7T8Z8HCQ/", folder=True,
        icon="https://yt3.googleusercontent.com/9Q_W3jAt7xm_JMGMpyXISgPzxEs6Wbl2WbDs1QNsIXvWsX-EnARu5a8D4icmUbgpi27XF6DW=s176-c-k-c0x00ffffff-no-rj")
                  
    Add_Dir(
        name="直播港澳台", url="plugin://plugin.video.youtube/channel/UC-UFD2pRujktkSyAD999mFg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngpu2fFPt98ST7y5VteaNW7jqfM40n6lyQgnLn6=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="中国档案室", url="plugin://plugin.video.youtube/channel/UCefCjYo0mhQSPydDVOKI8ew/", folder=True,
        icon="https://yt3.ggpht.com/Uf8yA1LOqbiFGRKgoSgIh-r-uS70EkrjZ6WZnjRN3xufE-o58X9gSAXUN15TUB_nQytW65UQ0g=s800-c-k-c0x00ffffff-no-rj")
                  
    Add_Dir(
        name="South China Morning Post", url="plugin://plugin.video.youtube/channel/UC4SUWizzKc1tptprBkWjX2Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AOPolaQE3Cc8vawbQH7ktxkhs09zZDQEUS3rIRjP02F90w=s800-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="南山见解", url="plugin://plugin.video.youtube/playlist/PLnhpRSU9pPuPCctFVGJ76B0UmA1EYL_wZ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRpMradlAYKn492HTcnLjoJG9z3SGndCyQHvxUh6A=s88-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="眉山论剑", url="plugin://plugin.video.youtube/playlist/PLnhpRSU9pPuPpzgY8mY4v3KOPEEHW2VOB/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRpMradlAYKn492HTcnLjoJG9z3SGndCyQHvxUh6A=s88-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="侦缉队", url="plugin://plugin.video.youtube/playlist/PLnhpRSU9pPuMxEHquQfOsZ5Tptqr2msdV/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRpMradlAYKn492HTcnLjoJG9z3SGndCyQHvxUh6A=s88-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Yan Talk 岩论", url="plugin://plugin.video.youtube/channel/UCwNGgFvBpxtU8JagZLzztzQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwniH6JQh4uZHOSRAUUV1mAvfjim1Tpr8buqblYEu=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="中國看客", url="plugin://plugin.video.youtube/channel/UCHQKRzrjwQzJy56frYj9qwQ/", folder=True,
        icon="https://yt3.ggpht.com/RxChiiNQ8HXyMqAs2qHSahi6U6R4RobVtU23h-n5BJPLEwVTmGKaDU98GMcqcqxPFjvrmilxtw=s800-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="江湖百晓生", url="plugin://plugin.video.youtube/channel/UCfqQVT1iMd1_cnahTy1Hieg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu9j_rEvpjo5xZh4u48JgIayLXCXaM7It_tOvtVNJQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="小岛大浪吹", url="plugin://plugin.video.youtube/channel/UCYPT3wl0MgbOz63ho166KOw/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AMLnZu-QZvqsA4E1PSVMddExMsBa9VFmEf_vnNz3OS5uTg=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Hot Topics Time", url="plugin://plugin.video.youtube/channel/UCZPCDOdY4m_m1bqjAl6P9rA/", folder=True,
        icon="https://yt3.googleusercontent.com/mnZx2ysQmJRkcDhUX4RHs8XRVbYm6_T0IGQHiZebPRafxOsDtCR8Rhrpc5L_kIcRJiBB5nKWiw=s176-c-k-c0x00ffffff-no-rj")
                
    Add_Dir(
        name="赖岳谦TV", url="plugin://plugin.video.youtube/channel/UCnrxxRlv2ZSSW4ApuEy8C0w/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-xnof2H-6jr8i1Rl5MojdVJXHzuv1Xfem8OUNwUA=s176-c-k-c0x00ffffff-no-rj")        

    Add_Dir(
        name="Chong San 沖先生", url="plugin://plugin.video.youtube/channel/UCsGqE-IVUCwyyi_WRsvVLJg/", folder=True,
        icon="https://yt3.ggpht.com/XbJK4MQLInnB3FCn0FI1KB3NgJdczSH43QbcX77XAsklvseyviRr93ZzFhmgWxI1swAvRBpybw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="中天新聞", url="plugin://plugin.video.youtube/channel/UCpu3bemTQwAU8PqM4kJdoEQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu_GcqEtH92jxUu-uPnd6Z2KRScKh_Qi1T9M0mgluQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="時政焦點", url="plugin://plugin.video.youtube/channel/UCHGg-bh_-x6YqVakEkql49A/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSPUvq0fkbU5RcOHc84lMOHo-gC0LJV6Js-wDO8sA=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="屈機TV", url="plugin://plugin.video.youtube/channel/UCN0eCImZY6_OiJbo8cy5bLw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSgEAGosPXetUZ8L_3eSFfYeTRWV159HSdrqWb7=s176-c-k-c0x00ffffff-no-rj")
                 
    Add_Dir(
        name="K2秀", url="plugin://plugin.video.youtube/channel/UCLqn_8sNfaye3wwNC1PfPIQ/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AGIKgqPdKlAR7CK-HehxGLPXfIeZS0jwgy9K5COLqWtb=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="Ming仔", url="plugin://plugin.video.youtube/channel/UCDoEdJo-PI-EKGNKomwLroQ/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AL5GRJWXSWaein_lDcN-f3ARHQkXEwXDWuH3xDHIwmWv0g=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="東網點評",
        url="plugin://plugin.video.youtube/channel/UC4NjmIegGw-HyQCmxwAEZBQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwniNC13K7MkFYxvSslIs1iPz9oBLje83s1LWGd4Tlw=s88-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="冼師傅講場", url="plugin://plugin.video.youtube/channel/UCFRBCHEqZNJ2Rb1IjrCC8Zw/", folder=True,
        icon="https://yt3.ggpht.com/a/AGF-l7_Qg35rIi0wFPrOGCObxPdm5k2y8qSAX6a4Og=s288-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="傅正", url="plugin://plugin.video.youtube/playlist/PLr0JU8OOrK4iENkcC5UWrHM88Hbr5X7QU/", folder=True,
        icon="https://i1.hdslb.com/bfs/face/b5a5301e9d55f4a7fa24cbc84690eeb9b86c5ad6.jpg@240w_240h_1c_1s.webp")

    Add_Dir(
        name="楊世光在金錢爆", url="plugin://plugin.video.youtube/channel/UCrm095p7ZHRS1njmQ1wkgCg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLS9plBmDiY6CoMUPNK5JWYGgfYGojwL7JS8X51jiw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="李天豪", url="plugin://plugin.video.youtube/channel/UCOrcp--cu4Egwdc07X44btA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSFhfNqDOvZE3pJ8sP_OPH-iSHt5PeDuW0w8qH1KA=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="王志郁Plus", url="plugin://plugin.video.youtube/channel/UCy-pqt2qjYVDZqwBiTS9yDA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRf9DO0RtOk7gZNyUrpBYau3TSixouNJHGZgD2N2g=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="我是柳傑克", url="plugin://plugin.video.youtube/channel/UC000Jn3HGeQSwBuX_cLDK8Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSyvQcw2l-ZhydsWKuTwQ3d4zoNA0joKQArA0aiXw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="东京自干五-长脸博士传媒", url="plugin://plugin.video.youtube/channel/UCzjhdu0yMChb8vRz8Ky3LCg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSdTjWgSLMuKdSnt-FwqUYsfMMSNSXBsyzLApXXxw=s88-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="WION", url="plugin://plugin.video.youtube/channel/UC_gUM8rL-Lrg6O3adPW9K1g/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTjMUv7cELVis5Au9R2HRytJnMtLShdD_k4IaeFQA=s176-c-k-c0x00ffffff-no-rj")
                
    Add_Dir(
        name="Asian Boss", url="plugin://plugin.video.youtube/channel/UC2-_WWPT_124iN6jiym4fOw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSHNaY_YBOYiS4J4pHleM9h2LhgpOFTOGqU9AThpw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="胡锡进Global Times", url="plugin://plugin.video.youtube/channel/UCVD-MGxD71IQUk9_hHq8MdA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnh07drypjn7U6BZ-3_vW4FTbAZXrU8Q195P0sVO=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="诚阅 ChengYue", url="plugin://plugin.video.youtube/channel/UCd6umYVQpBZ9CIyCwe8Kg7w/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJxgeqxuisbDAlXj9v7wI6b_1z-pYW8wHRYjAylu=s176-c-k-c0x00ffffff-no-rj")
            
    Add_Dir(
        name="全球大視野", url="plugin://plugin.video.youtube/channel/UCiwt1aanVMoPYUt_CQYCPQg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnj2DjFWmKz2gqvNpgy5ElO_Zd25NGbbapBy-0mEFw=s176-c-k-c0x00ffffff-no-rj-mo")
                
    Add_Dir(
        name="军政速递", url="plugin://plugin.video.youtube/channel/UCdyh01hxhKg6uTurnLdickQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngx1r4JjslB2Q8aVBbn1pVCFyK6hu1vb7zlIDX1=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="快看资讯", url="plugin://plugin.video.youtube/channel/UCgkHTZsCdH8P9z7lazTXN3g/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzB-L487V6_1Q5-qx5hw2xrsMsZVqF0BLE9fg=s288-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="點新聞", url="plugin://plugin.video.youtube/channel/UCcrnNcl12onXCeS_3Bi0a2Q/", folder=True,
        icon="https://yt3.ggpht.com/a/AGF-l79aat4yF9qy5E0uqRiFt4d4t40Q4VZknha4IA=s288-c-k-c0xffffffff-no-rj-mo")
        
    Add_Dir(
        name="新潮民", url="plugin://plugin.video.youtube/channel/UCzV8ytvWEGtMWk0wt9zA1Ng/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnjxUU5eZLp-MAoU7hJDFSlJMmRT2O5KrSc1XO38cw=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="KOLHK 時事梓引", url="plugin://plugin.video.youtube/channel/UCG6WtLOTXySl1terUhQYWCA/", folder=True,
        icon="https://yt3.ggpht.com/NDTvGFU50VALAyt8F6jbhS73gSkpgIGRcWMa6umMEgdCSVj7Dwug7552xLCTi6giI6L0ZMpEi5w=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="陳穎欣Joephy Chan", url="plugin://plugin.video.youtube/channel/UCvlBe-TQfjLFINSSYQt9Tjg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyelSSdVCQhptmAxwrUMmVMVSO13zueU_mOnQ=s144-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="大樹與木頭 ‧Y2K Channel", url="plugin://plugin.video.youtube/channel/UCFfLWSnUCblI4Lpsph7H1lA/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJymkSjncCTZJiz3q8Vpss4LVzKnfX5KctTyPmteRA=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="娜娜琳", url="plugin://plugin.video.youtube/channel/UCn0Lyn2rx4ZJcHgD-jgNhiw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnjwbRazIvLSThIvvt1Z4auaoaNzlsAafuzot2HN=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="空姐牛肉飯Annie", url="plugin://plugin.video.youtube/channel/UCpytXTSrsqbCjmqb6MfMrmw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnjE3Ycu_cj3RRlhLzJc0BkKkthOvAYUeV9HIkhXBg=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="有聲專欄", url="plugin://plugin.video.youtube/playlist/PL50ryNxlMBN5kwOJ_DvTeNXhBrQRbm9N6/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyGzUS1KUF4yZ1VnwWZI8UxEU-4KJhHLr1Lf_dwfA=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="火鍋大王Nathan Rich", url="plugin://plugin.video.youtube/channel/UCaSlyjhR4WC7QhYuaivxb6g/", folder=True,
        icon="https://yt3.ggpht.com/a/AGF-l78ngY4lsF1M-z5fRTQxaHGjsHEOJ5Ly2gpjyQ=s288-mo-c-c0xffffffff-rj-k-no")

    video_fav = xbmcgui.ListItem(label="How can they own our land?")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=T_ihqlYWEhk", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="大开眼界-“萝莉岛”的秘密")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=v5TjSzfgcrQ", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="香港史上最大騙局？一片睇清JPEX爆煲！")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=3jsdc5oZSEA", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="JPEX龐氏騙局背後的真相")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=CWNThUAenCU", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="【科普/体验】数字人民币是什么？使用体验如何？数字人民币简单科普与试点地区体验")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=h6KeIG1umtI", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="台積與中芯最終命運, 巴菲特購台積股權之謎")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=EKujoLAEO5A", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="国产GPU如何突围？AI芯片与CPU/GPU有何不同？")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=7EXDp6c9n-Q", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="美联储加息減息“剪羊毛")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=T6cVPxET77I", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="美国如何利用加息降息周期收割全世界")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=dhEsJt7qo8o", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="美國長臂管轄")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=bc26Tt5B9Ik", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="南海那场世纪对峙")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=WXJ6LC4mvHM", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="2019金燦榮趣談中美關係和世界格局")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=VR6iYQeSAVI", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="中国反霸的成绩")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=Ygr8mg-fMHg", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="一堂課帶你看懂烏克蘭危機")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=m6sRBEpHBpw", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="美国的地缘防线")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=BuRjLkS-dUM", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="NGO颠覆史（上）")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=Tb_g8UgkyRI", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="美國佔領一個國家的12個步驟")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=qyqKDomSeUk", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="美國掠奪一個地方的四部曲")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=zffGd8RQhTA", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="美國謀害中國陷入圈套的十個步驟1")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=ddlyL6gqffM", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="美國謀害中國陷入圈套的十個步驟2")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=6X4DHDuILIo", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="美國謀害中國陷入圈套的十個步驟3")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=lxdQPMcxz78", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="孟晚舟案")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=NOkZeEC5li8", listitem=video_fav, isFolder=False)

    video_fav = xbmcgui.ListItem(label="从英雄到恶魔，环保少女被欧洲清算")
    video_fav.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url="plugin://plugin.video.youtube/play/?video_id=ylJyflgz3YI", listitem=video_fav, isFolder=False)
 

if mode == 0 or mode is None:
    Main()
        
xbmcplugin.endOfDirectory(plugin_handle)
