import xbmc
import xbmcplugin
import xbmcgui
import sys
import os

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'videos')

m3u_path = xbmc.translatePath('special://home/addons/plugin.video.playlist/resources/playlist.m3u')

if not os.path.exists(m3u_path):
    xbmcgui.Dialog().notification("Playlist Not Found", "playlist.m3u is missing", xbmcgui.NOTIFICATION_ERROR)
    xbmcplugin.endOfDirectory(addon_handle)
    sys.exit()

with open(m3u_path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

title = "Unknown"
for line in lines:
    line = line.strip()
    if line.startswith("#EXTINF:"):
        parts = line.split(",", 1)
        if len(parts) > 1:
            title = parts[1].strip()
    elif line.startswith("http"):
        url = line
        li = xbmcgui.ListItem(label=title)
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': title})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)

xbmcplugin.endOfDirectory(addon_handle)
