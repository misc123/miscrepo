# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from common import *
from favourites import *

params = get_params()
mode = None

plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.favourites')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')

#===============================================================================
def Main():


    Add_Dir(
        name="【三体 Three-body】", url="plugin://plugin.video.youtube/playlist/PLDWJ213d2Ucr-3q9LDF9P1_j3Rr3GMJeS/", folder=True,
        icon="special://home/addons/plugin.video.favourites/icon/3body.jpg")

    Add_Dir(
        name="西游记 The Monkey King", url="plugin://plugin.video.youtube/playlist/PLUW1PvNEHJtFjnTpLQLBXGELSQ76s-EAq/", folder=True,
        icon="https://p5.img.cctvpic.com/fmspic/vms/image/2013/08/19/VSET_1376895834085194.jpg")

    Add_Dir(
        name="【Mostly ENGLISH】琅琊榜 Nirvana In Fire", url="plugin://plugin.video.youtube/playlist/PLzfNoYeTnhXK8DEE7VrcB4E8TTgJcdhfB/", folder=True,
        icon="https://upload.wikimedia.org/wikipedia/en/9/9b/Nirvana_In_Fire_%28Lang_Ya_Bang%29_official_poster.jpg?20200531015616")

    Add_Dir(
        name="Nirvana in Fire II", url="plugin://plugin.video.youtube/playlist/PL2Vcf2jYz5de-EJNo-L_VYsw-k0iimk-V/", folder=True,
        icon="https://i.ytimg.com/vi/NzkEqSW5Mo0/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLCfkXhbRSvLYhNGAUXZ8s8PJnMTPA")

    Add_Dir(
        name="御赐小仵作", url="plugin://plugin.video.youtube/channel/UC3PKcYXUAhao3p4kuNS4_9w/playlist/PL9yRf-Ghij3YIJj8j2Y8rEVMWBqGuLD9A/", folder=True)

    Add_Dir(
        name="iQIYI Movie English", url="plugin://plugin.video.youtube/channel/UCZrZaZM9IfX-uB-9yWf5gfQ/playlists/", folder=True,
        icon="https://yt3.googleusercontent.com/Qe7v9gfYFfTlZZcbVl1rmphhs2q-ui_sMLN3E28-aOfNnSzwt5IEGBK5o7-gTdxxcswrb66GzeQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="China Drama", url="plugin://plugin.video.youtube/channel/UC-Ig34sG4fuRLcoeUrfnAiA/playlists/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AIdro_muDW2k2d4hNRbtUiECawR9AvUqofsUkq3d3eUS1XoF2w=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="FRESH DRAMA+", url="plugin://plugin.video.youtube/channel/UC9KQJM5HxBAW5RnRelxhqNw/playlists/", folder=True,
        icon="https://yt3.googleusercontent.com/m86G_czg6Wno9vrGnMgkiAkv6yMYb26mpPXnHFxP-_ft5py1-caUTeLuKty02ws3v8_xHY9K_A=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="YoYo English Channel", url="plugin://plugin.video.youtube/channel/UC3UUwfyntghfisq02q5v2tw/playlists/", folder=True,
        icon="https://yt3.googleusercontent.com/7YzSNy_hRWdtUzWgFM1X5UGi44SOhKHYghh1XKVv7aT5jaEEo5453a2otjCgq6erBTlztno_tw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="China Zone - English", url="plugin://plugin.video.youtube/channel/UClvEgMB1W6pJ88Sej_JNMcA/playlists/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AIdro_m1JHZ3XqivNBk5x1ah3McrWYS6lP70BzXJkNp_bMzbYQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="King of War", url="plugin://plugin.video.youtube/channel/UCH8_4qQX9Ip_ykfrZH8gDkQ/", folder=True,
        icon="https://yt3.googleusercontent.com/ekPyYCbmvIU3DmEzjEsoj3YKR8XYtC1KYDDfCvXxThxlpSDuhWsWhFg6aILe0feIwHhuJ8RpVg=s176-c-k-c0x00ffffff-no-rj")

 
if mode == 0 or mode is None:
    Main()
        
xbmcplugin.endOfDirectory(plugin_handle)
