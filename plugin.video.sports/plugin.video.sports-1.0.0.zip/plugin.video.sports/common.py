# -*- coding: utf-8 -*-

import os
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon  # Explicitly import xbmcaddon
import urllib.parse
import xbmcvfs  # Import xbmcvfs for path translation

# Set up some necessary paths and constants
PROFILE = xbmcvfs.translatePath('special://profile/')  # Use xbmcvfs for path translation
DATABASE = os.path.join(PROFILE, 'Database')
BASE = 'http://example.com/base_url/'  # Modify this as needed
home = xbmcaddon.Addon(id='plugin.video.sports').getAddonInfo('path')

# Function to add directory item to Kodi's directory
def addDirMain(name, url, mode, iconimage, fanart):
    try:
        u = sys.argv[0] + "?url=" + urllib.parse.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.parse.quote_plus(name)
        liz = xbmcgui.ListItem(name)
        liz.setArt({'thumb': iconimage, 'icon': "DefaultVideo.png", 'fanart': fanart})
        liz.setInfo(type="Video", infoLabels={"Title": name})
        liz.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    except Exception as e:
        print(f"Error in addDirMain: {e}")
        u = sys.argv[0] + "?url=" + urllib.parse.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.parse.quote_plus(name)
        liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)

# Function to parse URL parameters from Kodi
def get_params():
    param = {}
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        cleanedparams = paramstring.replace('?', '')
        if paramstring.endswith('/'):
            paramstring = paramstring[:-2]
        pairsofparams = cleanedparams.split('&')
        for param_pair in pairsofparams:
            splitparams = param_pair.split('=')
            if len(splitparams) == 2:
                param[splitparams[0]] = splitparams[1]
    return param

# Utility function for regular expression matching
def regex_get_all(text, start_with, end_with):
    r = re.findall(f"(?i)({start_with}[\S\s]+?{end_with})", text)
    return r
