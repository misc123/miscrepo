# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from common import *
from news import *

params = get_params()
mode = None

plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.news')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')

#===============================================================================
def Main():

    addDirMain('新聞及娛樂',BASE,10,'special://home/addons/plugin.video.news/icon/news.png','fanart.jpg')
    addDirMain('星火电视直播',BASE,20,'special://home/addons/plugin.video.news/icon/startfire.png','fanart.jpg')
#===============================================================================
#@route(mode='星火电视直播')    
def 星火电视直播():

    package_name = "com.aesq.yh"
    activity_name = ""  # You may leave this empty or provide the specific activity name if required
    xbmc.executebuiltin('StartAndroidActivity({}, {})'.format(package_name, activity_name))
#===============================================================================   
#@route(mode='新聞及娛樂')    
def 新聞及娛樂():

    Add_Dir(
        name="無綫新聞", url="plugin://plugin.video.youtube/channel/UCvdc-bj7Onv5XhEC5z8_JUg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AGIKgqOZnL3_RjpUFbfe1ZI8rfGNLjFsMgMcsTnSg3gOSA=s800-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="明報5:30加拿大新聞", url="plugin://plugin.video.youtube/channel/UCuaiQk1XUTc3q4HaL36E_Dg/", folder=True,
        icon="https://yt3.googleusercontent.com/QxVeO0C3nsZjumGWHkaVzh9zWnLdr30i93jS0I0I-glgtL8x_B4ZFd_J5Acb-5t1RBzcy-0q=s176-c-k-c0x00ffffff-no-rj")

    url = "plugin://plugin.video.icdrama/?action=versions&url=http%3a%2f%2fwww1.adramas.se%2fhk-show%2f1244-scoop%2f"
    list_item = xbmcgui.ListItem(label="東張西望-用STREAM播放")
    list_item.setInfo("video", {"title": "東張西望"})
    list_item.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)
       
    Add_Dir(
        name="東張+", url="plugin://plugin.video.youtube/channel/UCAQsetoOYIHCbceCTJuu5sg/", folder=True,
        icon="https://yt3.googleusercontent.com/jvkGHsiHDYA5TgfszwTdSiIAf_fuTXaWRkbbOqnBoUxssWNerSQbO3k5Chs8PQ2ytpl25jNre4o=s160-c-k-c0x00ffffff-no-rj")

    url = "plugin://plugin.video.icdrama/?action=versions&url=http%3a%2f%2fwww1.adramas.se%2fhk-show%2f9469-midlife-sing-shine-3%2f"
    list_item = xbmcgui.ListItem(label="中年好聲音3-用STREAM播放")
    list_item.setInfo("video", {"title": "中年好聲音3"})
    list_item.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    Add_Dir(
        name="中年好聲音3", url="plugin://plugin.video.youtube/kodion/search/query/?q=中年好聲音3", folder=True,
        icon="https://upload.wikimedia.org/wikipedia/zh/9/9a/%E4%B8%AD%E5%B9%B4%E5%A5%BD%E8%81%B2%E9%9F%B3_3_Logo.jpg")

    Add_Dir(
        name="中年好聲音3-張崇德官方頻道", url="plugin://plugin.video.youtube/channel/UCDWMCTdktBBJzAo-isCCneA/", folder=True,
        icon="https://yt3.googleusercontent.com/QFGZ7Rt5kA-5pUvDHBKb5jcuw_KztYRrEHL4FlsgZSWBgL-EDa2lSwiFvoCWldwLyrbNyL16mHM=s160-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="中年好聲音3-Roger歌唱教室", url="plugin://plugin.video.youtube/channel/UCp330a_W8GwFhoGPJ7JrDVg/", folder=True,
        icon="https://yt3.googleusercontent.com/4svqX_rEWl5ClLTGuZY9YvTmfmHQWDK1YPXMZkfTf-bHSlJHReCV1yKYOfr1djdyspCGhgg7dQ=s160-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="張佳添音樂頻道", url="plugin://plugin.video.youtube/channel/UCo0dp33gQlIrvfr_erehWZQ/", folder=True,
        icon="https://yt3.googleusercontent.com/TSu6Z9odR5jDOhpWujnW7n4BvHlOrVxkA-Qf_b0QhwpcQsn7P2aRzEb-fYuDSKtK_1FPNHNb=s160-c-k-c0x00ffffff-no-rj")

    url = "plugin://plugin.video.icdrama/?action=versions&url=http%3a%2f%2fwww1.adramas.se%2fhk-show%2f8827-midlife-sing-shine-2%2f"
    list_item = xbmcgui.ListItem(label="中年好聲音2")
    list_item.setInfo("video", {"title": "中年好聲音2"})
    list_item.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    Add_Dir(
        name="危險人物2.0-翁靜晶", url="plugin://plugin.video.youtube/channel/UCAlVuubC3GE6kFFeNBEkoUQ/", 
        icon="https://yt3.googleusercontent.com/AGlwxLTfEBepWCn50VeM4OP3ELo2B2pAn9n8PZ1JSr5_8E6Esjw11R2ZxMzfniTVXZtnknjd=s176-c-k-c0x00ffffff-no-rj", folder=True)

    Add_Dir(
        name="Lorey Chan 好書推介", url="plugin://plugin.video.youtube/kodion/search/query/?q=Sun Channel Lorey", folder=True)
        
    Add_Dir(
        name="無窮之路4一帶一路", url="plugin://plugin.video.youtube/playlist/PL6xnAvlFTCA0ipcCOARO2XLs7Sqo-BUsv/", folder=True,
        icon="https://img.tvb.com/mytvs/poster/1419/h_141813_v1_615.jpg")
        
    Add_Dir(
        name="無窮之路3無垠之疆", url="plugin://plugin.video.youtube/playlist/PLsWIbSNBW_yiXzEjIfXj47wzhE0Tc0YWy/", folder=True,
        icon="https://i0.xiaoyakankan.com/data/2401/0748/0ad750.jpg")

    Add_Dir(
        name="呃錢", url="plugin://plugin.video.youtube/kodion/search/query/?q=呃錢", folder=True,
        icon="https://programme.tvb.com/thumbor/DunTVF7sleQcdRUgWc7J8vQtoXU=/0x0/public/programme/poster/202410/7102fa79-cf19-448a-a59b-09e1aebef062.jpeg")

    Add_Dir(
        name="創科導航", url="plugin://plugin.video.youtube/channel/UCvdc-bj7Onv5XhEC5z8_JUg/playlist/PLhbhEbEB8P3rRl2ZY291RTpgpe0fD6MlX/?category_label=TVB%20%e5%89%b5%e7%a7%91%e5%b0%8e%e8%88%aa", folder=True,
        icon="https://programme.tvb.com/thumbor/7Nha9i_C-v2bKQ8R8XrWfLW2J8Y=/0x0/public/programme/poster/202302/3d82b174-ae39-4f09-8bff-df48997ae87b.jpeg")

    Add_Dir(
        name="猜猜我是誰", url="plugin://plugin.video.youtube/kodion/search/query/?q=猜猜我是誰TVB", folder=True)

    Add_Dir(
        name="新聞掏寶", url="plugin://plugin.video.youtube/kodion/search/query/?q=TVB 新聞掏寶", folder=True)

    Add_Dir(
        name="香港01", url="plugin://plugin.video.youtube/channel/UCTxyBu9VWUq5LXezXwy_SGg/", folder=True)
        
    Add_Dir(
        name="星島頭條", url="plugin://plugin.video.youtube/channel/UCSyH9MRwMn-kdq5GCV4tYCA/", folder=True,
        icon="https://yt3.ggpht.com/CPVP3oOObqdhof1NBBle5mBmSyoy-sbXMY-F2It7XJsgB2PtYgSNqEYIfY40mLPb8btDBYCoVg=s800-c-k-c0x00ffffff-no-rj")

    url = "plugin://plugin.video.icdrama/?action=versions&url=http%3a%2f%2fwww1.adramas.se%2fhk-show%2f9202-tristar-academy"
    list_item = xbmcgui.ListItem(label="福祿壽訓練學院")
    list_item.setInfo("video", {"title": "福祿壽訓練學院"})
    list_item.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    url = "plugin://plugin.video.icdrama/?action=versions&url=http%3a%2f%2fwww1.adramas.se%2fhk-show%2f9207-shenzhen-foodbusters%2f"
    list_item = xbmcgui.ListItem(label="吃貨橫掃深圳")
    list_item.setInfo("video", {"title": "吃貨橫掃深圳"})
    list_item.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    Add_Dir(
        name="巴士的報", url="plugin://plugin.video.youtube/channel/UCCBNE0MbFaSooy7ZhJwXSrg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnhub9qdg-gC-HVcqH6zhr9kCNf31qsocRmBoDEYqA=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="杨风時評", url="plugin://plugin.video.youtube/channel/UCE05tYKEsEk7Qmhwg5pqcKw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngr3CJnciQrh3Hw2p_QM68a6Qpdli_yzt_MPNCj=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="無綫新聞", url="plugin://plugin.video.youtube/channel/UC_ifDTtFAcsj-wJ5JfM27CQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AGIKgqOZnL3_RjpUFbfe1ZI8rfGNLjFsMgMcsTnSg3gOSA=s800-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="無綫10:00一小時新聞", url="plugin://plugin.video.youtube/playlist/PLhbhEbEB8P3ocOvkDXn8r9Rq4sP3y2THH/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AGIKgqOZnL3_RjpUFbfe1ZI8rfGNLjFsMgMcsTnSg3gOSA=s800-c-k-c0x00ffffff-no-rj")        

    Add_Dir(
        name="亚洲电视新闻", url="plugin://plugin.video.youtube/channel/UCjefHwE2Qb_XG72zsvJHQjw/", folder=True,
        icon="https://yt3.ggpht.com/xRbCtrwqyUDFUGg5Rd4X2qYMpTD2YbmZJG17hC5QDu3N00-NvBQ1g5GT8gbsZCWbDFQjwh3iYA=s800-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="ATV亞洲電視", url="plugin://plugin.video.youtube/channel/UCxfYBt0jWPtfxoCNP6KggPA/playlists/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AGIKgqP1pO5e7SrGtqcgFgWdoiZpXQ1D77Ly9cFyTjfw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="TVB娛樂新聞台", url="plugin://plugin.video.youtube/channel/UC5dp6FxyIJmXLQv-9RYOTfA/", folder=True,
        icon="https://yt3.ggpht.com/knixM-0FTOT19vikhqwTaVs5dGMabDPZDnqiqnWFTQ20lxSfEY5x8tcvi-cv4plSg_6Xti4D=s800-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="HK E News", url="plugin://plugin.video.youtube/channel/UCXqhKkakjAddiWXXPEQbH7g/", folder=True,
        icon="https://yt3.ggpht.com/_EwxFvlmlf5RNFJjYwiuUtwNI35IQ5B9WIxDi0HyXQGhzkhkH0U-YcBpjs8cUlw24Zkocfd92w=s800-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="TVB Best Drama 熱播劇場", url="plugin://plugin.video.youtube/channel/UC-vdzV9IVeIsp0YSCm16CkQ/playlists/", folder=True)

    Add_Dir(
        name="TVB Drama – Comedy 喜劇台", url="plugin://plugin.video.youtube/channel/UC3zIehcse5c7xRdE-baFVfw/playlists/", folder=True)

    Add_Dir(
        name="TVB Crime&Mystery Channel 神秘頻道", url="plugin://plugin.video.youtube/channel/UCYEcRcwNhGS3fAYVrOneFew/playlists/", folder=True)

    Add_Dir(
        name="TVB Mystery Channel 神秘頻道", url="plugin://plugin.video.youtube/kodion/search/query/?q=TVB%20Mystery%20Channel%20%e7%a5%9e%e7%a7%98%e9%a0%bb%e9%81%93&amp;search_type=playlist", folder=True)

    Add_Dir(
        name="TVB Drama – Action WuXia 動作武俠", url="plugin://plugin.video.youtube/channel/UCcadjKOwi1MLRlXb78aGx-Q/playlists/", folder=True)

    Add_Dir(
        name="TVB Variety Show 綜藝娛樂", url="plugin://plugin.video.youtube/channel/UCflTI_nq4yyQK3B9UITRJFw/", folder=True)

    Add_Dir(
        name="TVB Food &amp; Travel 飲食旅遊", url="plugin://plugin.video.youtube/channel/UC0FCCZhGfa-BnohSaQjwXGA/playlists/", folder=True)

    Add_Dir(
        name="TVB Anywhere Life", url="plugin://plugin.video.youtube/kodion/search/query/?q=TVB%20Anywhere%20Life", folder=True)

    Add_Dir(
        name="TVBusa - 東張西望", url="plugin://plugin.video.youtube/kodion/search/query/?q=tvbusa%e6%9d%b1%e5%bc%b5%e8%a5%bf%e6%9c%9b", folder=True)

    Add_Dir(
        name="香港V", url="plugin://plugin.video.youtube/channel/UCJngFlPRJELUXCwl08PZvqg/", folder=True)

    Add_Dir(
        name="i-Cable News 有線新聞", url="plugin://plugin.video.youtube/playlist/PLIpRvnEkgEeVUPzeLS6JraRwmD3YcWkMz/", folder=True)

    Add_Dir(
        name="ViuTV", url="plugin://plugin.video.youtube/channel/UCHOmxBZKt6uCFqoCvRHnSgQ/playlists/", folder=True)

    Add_Dir(
        name="AMM 亞洲心動娛樂", url="plugin://plugin.video.youtube/channel/UCTsSh20JYvvFlHQ9NYzj1mg/playlists/", folder=True)

    Add_Dir(
        name="MPWeekly明周", url="plugin://plugin.video.youtube/user/Mingpaoweekly/", folder=True)

    Add_Dir(
        name="HK娛樂驛站", url="plugin://plugin.video.youtube/channel/UCGT-CnExA28xbZNX4AYp1tg/", folder=True)

    Add_Dir(
        name="明星周刊", url="plugin://plugin.video.youtube/channel/UCvM04RAO0VeVLoLqRF_MEcQ/", folder=True)

    Add_Dir(
        name="TVB (official)", url="plugin://plugin.video.youtube/channel/UCD2SNRlEjxJODlwaKx-BoRw/playlists/", folder=True)

    Add_Dir(
        name="亞視精選 Drama Asia", url="plugin://plugin.video.youtube/channel/UCCyJ08FwnuhEvsT7QSrWBhA/playlists/", folder=True)

    Add_Dir(
        name="ViuTV World", url="plugin://plugin.video.youtube/kodion/search/query/?q=ViuTV%20World&amp;search_type=playlist", folder=True)

    Add_Dir(
        name="有線電視節目列表", url="plugin://plugin.video.youtube/channel/UC_q7e5XYJB0JDGagcF0KW0w/playlists/", folder=True)

    Add_Dir(
        name="Now 財經新聞", url="plugin://plugin.video.youtube/channel/UCChMBgirwM2nnT3Bbe8METQ/playlists/", folder=True)

    Add_Dir(
        name="八八通", url="plugin://plugin.video.youtube/channel/UCeFbWIhDj_tjTOTe1P3cVHA/", folder=True)

    Add_Dir(
        name="東Touch", url="plugin://plugin.video.youtube/user/EastTOUCHhk/", folder=True)

    Add_Dir(
        name="東周網", url="plugin://plugin.video.youtube/channel/UCsTeCS6s9YoNn2kbQVAgDsQ/", folder=True)

    Add_Dir(
        name="頭條日報", url="plugin://plugin.video.youtube/user/hkheadlinenews/", folder=True)

    Add_Dir(
        name="《危險人物》翁靜晶", url="plugin://plugin.video.youtube/channel/UCqz7Q8gOavVi_ZiGHePvLug/playlist/PLPbX1ivjKJuJ1SO0lDA0o8E80JEywnYl0/", folder=True)

    Add_Dir(
        name="奇聞觀察室", url="plugin://plugin.video.youtube/channel/UCnw2Vl-qbNYcJeeIV-16MUQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AGIKgqOu56Pp3uAfjADBSZBinsqe3MNaeMcC3oIjb0yi=s800-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="啾啾鞋", url="plugin://plugin.video.youtube/channel/UCIF_gt4BfsWyM_2GOcKXyEQ/", folder=True,
        icon="https://yt3.ggpht.com/zo9lw7zzI95m-tlSbVsDwnEoWqVySkb6T3wLWefuSHAclBCG2bQFVT2vSoTkPtme6IPdMKMplw=s800-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="自说自话的总裁", url="plugin://plugin.video.youtube/channel/UCgo_-fjJxnLwwwq5dSY72rg/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AIdro_l7MfWkgzsOXDABtNoHpW68JZI7-OuKzL_wefeqlw=s160-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="解密工作室", url="plugin://plugin.video.youtube/channel/UCtokllq2j9bzPD6XdcQP9mQ/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AIf8zZRZ45iZAxvJwgYMF74fWNIHlvijyGqomzt8UpJDlQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Mr. Atom 原子檔案", url="plugin://plugin.video.youtube/channel/UCjxWY5oD9I1LKaCJkOO1TKw/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AIf8zZTmCUuMK0_RdiDPQ4wCyksY_qFaxIsjIxf0xzc4bA=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Z檔案", url="plugin://plugin.video.youtube/channel/UCIraGjqGxcks1NeVA8P4gAA/", folder=True,
        icon="https://yt3.googleusercontent.com/DKkkUOp-OORYAXK84jjfMXpknxu6uW4RWs-_WqOcljeXADCJyNTQyg-bNElySXW2jEyOQJrsjVk=s176-c-k-c0x00ffffff-no-rj")
 
    Add_Dir(
        name="老高與小茉", url="plugin://plugin.video.youtube/channel/UCMUnInmOkrWN4gof9KlhNmQ/", folder=True,
        icon="https://yt3.googleusercontent.com/U6n1tM-bMbzyjnW3kIrs3Xdhcyxwri__7Ftm_lYuYBvPB1BRU-Z93Zvefc8TPzMUgJly4BKk=s160-c-k-c0x00ffffff-no-rj")
      
    Add_Dir(
        name="地球旅館", url="plugin://plugin.video.youtube/channel/UCgZwrKchqUs7C7YKxDe4Wkg/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AIdro_lPnjyxdN1_IySGSkBnj8i7BwFsvesOiiA1vzfSAJt5iQ=s160-c-k-c0x00ffffff-no-rj")
 
    Add_Dir(
        name="Just For Fun", url="plugin://plugin.video.youtube/channel/UCfmhgy-jmq_P2m-rSXsEq3g/", folder=True)

    Add_Dir(
        name="娛樂香港新聞透視", url="plugin://plugin.video.youtube/channel/UCLtcC8s-2JJ_5iUxcAO462Q/", folder=True)

    Add_Dir(
        name="明報新聞(多倫多,加國及其他)", url="plugin://plugin.video.youtube/channel/UCuaiQk1XUTc3q4HaL36E_Dg/playlists/", folder=True)

    Add_Dir(
        name="多倫多 WOWtv", url="plugin://plugin.video.youtube/channel/UC5kySUzP0p4Q4Y1rnQLX_bw/", folder=True)

    Add_Dir(
        name="恩雨之聲", url="plugin://plugin.video.youtube/channel/UCgwOhn9ghL2jY5qJEzpzSzw/", folder=True)

    Add_Dir(
        name="老王", url="plugin://plugin.video.youtube/channel/UCtb0R8m8xgS2C_6b3S_xLHA/", folder=True)

    Add_Dir(
        name="科学声音", url="plugin://plugin.video.youtube/channel/UCUBhobCkTLhgfUNRAgHSYmw/", folder=True)

    Add_Dir(
        name="這麼遠 那麼近-方東昇", url="plugin://plugin.video.youtube/channel/UCaA4Wqk9sf2prQbjoVBtnPw/playlist/PLCGAsPLmtY28brHkRXonte3LDEY7pr_X5/", folder=True)

    Add_Dir(
        name="長命百二歲-方東昇", url="plugin://plugin.video.youtube/channel/UCvdc-bj7Onv5XhEC5z8_JUg/playlist/PLhbhEbEB8P3r7CBSv0zuLCHq7a-AGWU9U/", folder=True)

    Add_Dir(
        name="世界零距離-方東昇", url="plugin://plugin.video.youtube/channel/UCvdc-bj7Onv5XhEC5z8_JUg/playlist/PLhbhEbEB8P3qHxdq__peUJM2aM1zc7YVs/", folder=True)

    url = "plugin://plugin.video.icdrama/?action=versions&url=http%3a%2f%2fwww1.adramas.se%2fhk-show%2f8499-sleep-right-sleep-tight%2f"
    list_item = xbmcgui.ListItem(label="好睡好起-方東昇")
    list_item.setInfo("video", {"title": "好睡好起-方東昇"})
    list_item.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    Add_Dir(
        name="挑战不可能 Impossible Challenge", url="plugin://plugin.video.youtube/channel/UC3HLhJGcc_0Vse2UncGnxcQ/", folder=True)

    Add_Dir(
        name="志雲飯局", url="plugin://plugin.video.youtube/kodion/search/query/?q=%e5%bf%97%e9%9b%b2%e9%a3%af%e5%b1%80", folder=True)

    Add_Dir(
        name="多倫多華基主日粵語崇拜講道", url="plugin://plugin.video.youtube/kodion/search/query/?q=%e5%a4%9a%e5%80%ab%e5%a4%9a%e8%8f%af%e4%ba%ba%e5%9f%ba%e7%9d%a3%e6%95%99%e6%9c%83%e5%8d%88%e5%a0%82%e5%b4%87%e6%8b%9c", folder=True)

#xbmcplugin.endOfDirectory(plugin_handle)
    
#==========================================================================================================
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def regex_get_all(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
    return r

#====================================================

params=get_params()
url=None
name=None
mode = None
iconimage=None
description=None

#===================== Python 2 ======================

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#===================== Python 3 ======================

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.parse.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
#==========================================================================================================

if mode==10:
    新聞及娛樂()
 
elif mode==20:
    星火电视直播()
    
elif mode==None:
    Main()
        
xbmcplugin.endOfDirectory(plugin_handle)
