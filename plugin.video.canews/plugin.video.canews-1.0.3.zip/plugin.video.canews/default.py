# -*- coding: utf-8 -*-
import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from urllib.parse import parse_qs, unquote, quote
import xml.etree.ElementTree as ET
import os

plugin_handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.canews')

def get_params():
    param_string = sys.argv[2][1:] if len(sys.argv) > 2 else ''
    return dict(parse_qs(param_string))

params = get_params()
mode = int(params.get('mode', [0])[0])

def Main():
    # Path to favourites.xml inside plugin.video.playlist
    xml_path = xbmcvfs.translatePath('special://home/addons/plugin.video.playlist/resources/favourites.xml')

    if not os.path.exists(xml_path):
        xbmcgui.Dialog().notification("CA News", "Favourites file not found.", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"Favourites file not found at {xml_path}", xbmc.LOGERROR)
        return

    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()
    except Exception as e:
        xbmcgui.Dialog().notification("CA News", "Failed to load favourites.xml", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"Failed to parse XML: {e}", xbmc.LOGERROR)
        return

    for fav in root.findall('favourite'):
        name = fav.get('name', 'Unnamed')
        thumb = fav.get('thumb', '')
        raw_action = fav.text or ''

        if 'PlayMedia' in raw_action:
            match = re.search(r'PlayMedia\("(.+?)"\)', raw_action)
            action = 'playmedia'
        elif 'ActivateWindow' in raw_action:
            match = re.search(r'ActivateWindow\(10025,\s*\"(.+?)\",\s*return\)', raw_action)
            action = 'activatewindow'
        elif 'StartAndroidActivity' in raw_action:
            match = re.search(r'StartAndroidActivity\("(.+?)"\)', raw_action)
            action = 'startandroidactivity'
        else:
            xbmc.log(f"Unrecognized favourite action: {raw_action}", xbmc.LOGWARNING)
            continue

        if not match:
            continue

        url = match.group(1)
        plugin_url = f"plugin://{addon.getAddonInfo('id')}/?mode=1&action={action}&target={quote(url)}"
        list_item = xbmcgui.ListItem(label=name)
        if thumb:
            list_item.setArt({'thumb': thumb, 'icon': thumb, 'fanart': thumb})

        xbmcplugin.addDirectoryItem(handle=plugin_handle, url=plugin_url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(plugin_handle)

def handle_action():
    action = params.get('action', [None])[0]
    target = params.get('target', [None])[0]

    if not action or not target:
        xbmc.log("Missing action or target in parameters", xbmc.LOGERROR)
        return

    target = unquote(target)

    if action == 'playmedia':
        xbmc.executebuiltin(f'PlayMedia("{target}")')
    elif action == 'activatewindow':
        xbmc.executebuiltin(f'ActivateWindow(10025, "{target}", return)')
    elif action == 'startandroidactivity':
        xbmc.executebuiltin(f'StartAndroidActivity("{target}")')
    else:
        xbmc.log(f"Unknown action: {action}", xbmc.LOGERROR)

if mode == 0:
    Main()
elif mode == 1:
    handle_action()
