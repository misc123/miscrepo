# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from common import *
from movie import *

params = get_params()
mode = None

plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.movie')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')

#===============================================================================
def Main():

    addDirMain('爱壹帆',BASE,10,'special://home/addons/plugin.video.movie/icon/ifvod.png','fanart.jpg')
    addDirMain('電影頻道',BASE,20,'special://home/addons/plugin.video.movie/icon/movie.png','fanart.jpg')
    addDirMain('西片劇集',BASE,30,'special://home/addons/plugin.video.movie/icon/thecrew.png','fanart.jpg')
    
#===============================================================================      
#@route(mode='爱壹帆')    
def 爱壹帆():

    package_name = "tv.ifvod.classic"
    activity_name = ""  # You may leave this empty or provide the specific activity name if required
    xbmc.executebuiltin('StartAndroidActivity({}, {})'.format(package_name, activity_name))    

#===============================================================================      
#@route(mode='The Crew Movies')    
def 西片劇集():

    url = "plugin://plugin.video.thecrew"
    xbmc.executebuiltin('RunAddon(plugin.video.thecrew)')

#===============================================================================      
#@route(mode='電影頻道')    
def 電影頻道():

    Add_Dir(
        name="腾讯视频 - 华语经典剧场", url="plugin://plugin.video.youtube/channel/UC3PKcYXUAhao3p4kuNS4_9w/playlists/", folder=True,
        icon="https://yt3.ggpht.com/15IbaBAT5v4-H8ByIrdMUAD6ydUNe1GXVeKO7x9CjCjKnks4BCwlPtJpv7K60tithezo3Rsjuw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="优优独播剧场", url="plugin://plugin.video.youtube/channel/UCteBLoijWzlVFSR5BBtS_2Q/playlists/", folder=True,
        icon="https://yt3.ggpht.com/S4FHybeAASgDFb3qrCOoSMKVyCkvavdbqGNa2uaLjF8Cesqbz4M5X_tJH-mgqQv0ZljqfZCU-g=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="劇好看", url="plugin://plugin.video.youtube/channel/UCdOun-snJIWclxwjmUG7u_A/playlists/", folder=True,
        icon="https://yt3.ggpht.com/PqAo4x99rVhegcwBAuU5kP8jheixdrRrWIuTs73tW-9ABYCE6gp7O1zI3Z8jLQrHCFyvkw47=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="华策影视", url="plugin://plugin.video.youtube/channel/UCAMrnDQlsPnrScHun5PgrXw/playlists/", folder=True,
        icon="https://yt3.ggpht.com/PVRM0xCXzomgf7x3Y1mTM28-iKDojt6rZZnptnd5AZr_nSDh-sDD9X6Ixwb4b7JWOFVNqbmFtA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="捷成華視—經典劇", url="plugin://plugin.video.youtube/channel/UC4BVFK_Vs5BzvZxL2JLI1Jw/playlists/", folder=True,
        icon="https://yt3.ggpht.com/bg137I1yyY6OmqZAqMeh7uYdhTc5VozDdvCpGJgt89-cgTXXnwm3qTwkZQvndNpGAufrdBXQpA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="经典热播剧场", url="plugin://plugin.video.youtube/channel/UCGZgY9urf-stkr7cRUbQI1Q/playlists/", folder=True,
        icon="https://yt3.ggpht.com/Q3JqcdjUAjJfBSzzd6LhPo6jiTBAsmWKpiF2YVeokqc6T7HwfG9VGdOk7RMOJF7nfHr2cKH5m_E=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="甜宠追剧社", url="plugin://plugin.video.youtube/channel/UCdpka2ZttvQsOpUgPlTEkag/playlists/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu8-iYOnKDWeM1-7PnCFpzHJkPXgdcwHTeg-VQM=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="出色中国电视剧", url="plugin://plugin.video.youtube/channel/UC1WPfASy_zV0jj7PlafgELg/playlists/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-jNn1dhyC2VvpgrVqg2UOSfUClWuD8MX_9F5ot=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="China Zone 剧乐部", url="plugin://plugin.video.youtube/channel/UC0jYsshDZfOBZC9nIJn94Cg/playlists/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTa9hWJPYFBxHIxqYny3_iHAUC9QO3mI3YmoBVtxw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Caravan中文剧场", url="plugin://plugin.video.youtube/channel/UC5-YbNL-MUy1_tC9KSkEShw/playlists/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRge170h9wXXQH9PcZoN-S5kNCNuMlJyyJusEMd=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="經典熱播劇場", url="plugin://plugin.video.youtube/channel/UCGZgY9urf-stkr7cRUbQI1Q/playlists/", folder=True,
        icon="https://yt3.ggpht.com/Q3JqcdjUAjJfBSzzd6LhPo6jiTBAsmWKpiF2YVeokqc6T7HwfG9VGdOk7RMOJF7nfHr2cKH5m_E=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="精品電視頻道", url="plugin://plugin.video.youtube/channel/UCbOmEx8EeQ4PZpfRXHt-xJQ/playlists/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRauaL4g0SBQHG-VOHJsRy6uPbQcaeLZL4cfQFk4A=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="華劇場精選", url="plugin://plugin.video.youtube/channel/UCCxMNXfmWlukwNRRxPO-P9A/playlists/", folder=True,
        icon="https://yt3.ggpht.com/WsysYOr7Z9AnIVi_sOBfH3i6D8DF76DUQJ_NT3lvucFfnZqsGIE_AlikDWoN8AcQVItiznZd=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="網劇獨播", url="plugin://plugin.video.youtube/channel/UCixrmTfMM_YjeDHtXXcsg4w/playlists/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTrWkIzoE9RuQQ8XPv8T-Hi4M8EgV7C4VITsAgG=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="出色中国电视剧", url="plugin://plugin.video.youtube/channel/UC1WPfASy_zV0jj7PlafgELg/playlists/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQoQjMKUal6_4D3VYmCw42acWvK6LSfxz5_SORS=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Alex Cheng", url="plugin://plugin.video.youtube/channel/UC1pThebWi1K86SOd9o-wewQ/playlists/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQkaO1FOTVoaF_sB8hGYaW_2TreYB0PsgLjI1cr=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="乐视视频官方频道", url="plugin://plugin.video.youtube/channel/UCUuZe7OB0yHSYAfu8annGKQ/playlists/", folder=True,
        icon="https://yt3.ggpht.com/5oYw3Ie3p9XEtRrUNCFRJF2XNdvx_mm5IHpJ_RSvL8Ap602J60Xzm-MmLjON6jzWsRYvS36uijk=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="中剧独播", url="plugin://plugin.video.youtube/channel/UCAqDX_XjLlvhjY0eDqHpVQw/playlists/", folder=True,
        icon="https://yt3.ggpht.com/LajZNdYp96Du0xfboFsK9MbvalTcFjY61BaSBvSbntGviJfHRYA1lFtY8Nr5bIHMALhEyYOTTw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="大劇獨播", url="plugin://plugin.video.youtube/channel/UCNORTw_uosRNGgdEjwdHvuw/playlists/", folder=True,
        icon="https://yt3.ggpht.com/-ONpJ-FuL14Y/AAAAAAAAAAI/AAAAAAAAAAA/ja4pf5PLQPc/s100-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="大劇獨播Plus", url="plugin://plugin.video.youtube/channel/UCC5TlXzHiGi5L5KPbybIJrw/playlists/", folder=True,
        icon="https://yt3.ggpht.com/-dilMxQaE7sc/AAAAAAAAAAI/AAAAAAAAAAA/dPAtljTdAKY/s100-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="特工皇妃楚乔传", url="plugin://plugin.video.youtube/channel/UCtwHZjbJlnvPO_FdJ8nyNjg/playlists/", folder=True,
        icon="https://yt3.ggpht.com/-0V7dyPn9KxU/AAAAAAAAAAI/AAAAAAAAAAA/aVIw2x8rf9I/s288-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="NewTV偶像剧场", url="plugin://plugin.video.youtube/channel/UCSTsji9cUBBD6SOfw2fh5KA/playlists/", folder=True,
        icon="https://yt3.ggpht.com/-pqQfvAD7q-0/AAAAAAAAAAI/AAAAAAAAAAA/v9OI464JRKk/s288-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="NewTV热播剧场", url="plugin://plugin.video.youtube/channel/UCKn4SloJmZYNYNq6RgzgrHw/playlists/", folder=True,
        icon="https://yt3.ggpht.com/-3I2MApIMLHM/AAAAAAAAAAI/AAAAAAAAAAA/4vVxqjO5FZ4/s100-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="香港经典電影粵語", url="plugin://plugin.video.youtube/channel/UCMChq4sDciMlSWyD6ZRLBbg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTRcEKgeI3eYAi3__XeVPhup2luUVbJh7IN2Auo=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="周星驰电影", url="plugin://plugin.video.youtube/playlist/PLQpuAoYiMfLqjecowgK9rfsMG4qihx4GE/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRtNifww5Wan1xMrauY9bcY-JI5alD7HjEIdg=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="周星驰电影 粤语版", url="plugin://plugin.video.youtube/playlist/PLOfODbUDgknVEkAt964AnH0ac31sUYtRI/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTTAjBOAtQjGmsBu2FUU21vIyJ4k7oMNk62kkS8DA=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="粵語電影1", url="plugin://plugin.video.youtube/channel/UCuKO160G7i-F4DNLHluzxAQ/playlists/", folder=True, 
        icon="https://yt3.ggpht.com/-JnpfGgbZmVk/AAAAAAAAAAI/AAAAAAAAAAA/dstjUg4IoVs/s100-c-k-no-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="粵語電影2", url="plugin://plugin.video.youtube/search/?q=hong%20kong%20movies%20cantonese/", folder=True, 
        icon="https://upload.wikimedia.org/wikipedia/zh/thumb/f/fe/My_Lucky_Stars.jpg/220px-My_Lucky_Stars.jpg"
)

    Add_Dir(
        name="韓國電影1", url="plugin://plugin.video.youtube/channel/UCE-Az3DaIYjP9lqxSmQJUCw/playlist/PLx6zdlARSHzb7F26GQaDfvKHa7wiRW_VB/", folder=True,
        icon="https://upload.wikimedia.org/wikipedia/commons/1/13/KoreaSfilm.png"
)

    Add_Dir(
        name="韓國電影2", url="plugin://plugin.video.youtube/search/?q=korean%20movies%20chinese%20subtitles/", folder=True,
        icon="http://www.hancinema.net/images/logo_hancinema_pure.png"
)

    Add_Dir(
        name="日本電影", url="plugin://plugin.video.youtube/search/?q=japanese%20movies%20subtitles/", folder=True,
        icon="https://upload.wikimedia.org/wikipedia/commons/thumb/3/39/Japan_film_icon.svg/80px-Japan_film_icon.svg.png"
)

#xbmcplugin.endOfDirectory(plugin_handle)
    
#==========================================================================================================
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def regex_get_all(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
    return r

#====================================================

params=get_params()
url=None
name=None
mode = None
iconimage=None
description=None

#===================== Python 2 ======================

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#===================== Python 3 ======================

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.parse.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
#==========================================================================================================

if mode==10:
    爱壹帆()
    
if mode==20:
    電影頻道()
    
elif mode==30:
    西片劇集()

elif mode==None:
    Main()
        
xbmcplugin.endOfDirectory(plugin_handle)
